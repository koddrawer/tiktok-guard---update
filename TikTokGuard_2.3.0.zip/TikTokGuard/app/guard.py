#!/usr/bin/env python3
"""
TikTok Guard 2.1 - engine, Windows. Chỉ làm đúng 2 việc:

  1. Thấy thông báo "hạn chế hiển thị LIVE 10 phút"
        -> tắt live -> chờ 10 phút -> bật lại live.
  2. Thấy thông báo "hạn chế hiển thị LIVE 7 ngày"
        -> tắt hẳn live (không bật lại) -> Đăng xuất tài khoản
        -> hộp thoại "Log out" giữ nguyên ô tick "Keep the layout..." rồi bấm Log out.

Cứ N giây chụp cửa sổ TikTok LIVE Studio + OCR. Thông báo có thể là hộp thoại (có nút OK/Appeal)
hoặc tin nhắn "System" trong khung chat (không có nút).

Giao diện ở app.py. Dòng lệnh (dùng để kiểm tra):
  python guard.py --calibrate              chụp + OCR 1 lần, in ra những gì nhìn thấy
  python guard.py --simulate short|severe  giả lập 1 vòng cảnh báo (kèm --dry-run: không click thật)
"""
import argparse
import contextlib
import copy
import ctypes
import json
import logging
import logging.handlers
import os
import re
import sys
import threading
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path

__version__ = "2.3.0"
APP_NAME = "TikTokGuard"          # giữ nguyên tên để cài đè lên bản cũ
CONFIG_VERSION = 4

try:  # toạ độ chuột / chụp màn hình dùng chung pixel thật
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

BASE = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))  # nơi chứa code + icon


def _data_dir():
    env = os.environ.get("TIKTOK_GUARD_HOME")
    if env:
        p = Path(env)
    elif sys.platform == "win32":
        p = Path(os.environ.get("APPDATA") or Path.home()) / APP_NAME
    else:
        p = Path.home() / ".tiktokguard"
    p.mkdir(parents=True, exist_ok=True)
    return p


DATA = _data_dir()  # config.json, guard.log, handled.json, debug_last.png, last_warning.png, templates/account.png
CONFIG_PATH = DATA / "config.json"
TEMPLATES = DATA / "templates"
log = logging.getLogger("guard")

DEFAULTS = {
    "config_version": CONFIG_VERSION,
    "check_interval_seconds": 10,       # đọc chữ trên màn hình (OCR) mỗi chừng này giây
    "fast_probe_seconds": 2,            # giữa 2 lần đọc chữ: cứ mỗi chừng này giây nhìn nhanh (không OCR) xem có hộp thoại nút hồng hiện ra không; 0 = tắt
    "confirm_delay_seconds": 1.0,       # thấy cảnh báo rồi chụp lại lần 2 sau chừng này giây cho chắc, rồi mới thao tác
    "severe_logout": False,             # hạn chế >= 24 giờ: False = chỉ tắt live và KHÔNG bật lại; True = tắt live rồi đăng xuất tài khoản
    "restart_delay_seconds": 600,       # tắt live bao lâu rồi bật lại (cảnh báo ngắn)
    "auto_start_monitoring": True,
    "studio_window_title": "TikTok LIVE Studio",
    # --- nhận ra cảnh báo. OCR hay đọc dính chữ và BỎ DẤU tiếng Việt nên so khớp không phân biệt khoảng trắng/dấu câu/dấu thanh
    "warning_keywords": [
        "gifting suspended", "visibility restricted", "inorganic gift", "gifts are suspended", "live restricted",
        "restricted for", "suspended for",
        "đình chỉ chức năng tặng quà", "hạn chế khả năng hiển thị", "đã đình chỉ chức năng", "chức năng tặng quà",
        "hạn chế hiển thị", "tạm dừng quà"],
    "min_keyword_hits": 2,
    "severe_min_hours": 24,             # thời hạn ghi trong cảnh báo >= số giờ này thì coi là nặng (7 ngày)
    "severe_keywords": ["7 days", "7-day", "seven days", "7 ngày", "1 week", "one week", "1 tuần", "1 month", "one month", "1 tháng",
                        "permanent", "indefinite", "vĩnh viễn", "vô thời hạn"],      # dấu hiệu hạn chế dài khi không đọc được thời hạn cụ thể
    "labels": {
        "ok": ["OK", "Got it", "Understood", "Đã hiểu", "Đồng ý"],
        "appeal": ["Appeal", "Kháng nghị"],
        "system": ["System", "Hệ thống"],
        "end_live": ["End LIVE", "End live", "Kết thúc LIVE"],
        "confirm_end": ["End now", "End", "End LIVE", "Confirm", "Yes", "OK", "Kết thúc", "Xác nhận"],
        "go_live": ["Go LIVE", "Go live", "Bắt đầu LIVE", "Phát LIVE"],
        "logout": ["Log out", "Logout", "Sign out", "Đăng xuất"],
        "cancel": ["Cancel", "Hủy", "Huỷ"],
        "live_center": ["LIVE Center", "Trung tâm LIVE"],
    },
    # bảng tổng kết hiện ra ngay sau khi tắt live (Duration, Total views...). Phải bấm X của bảng thì mới thấy nút Go LIVE
    "summary_keywords": ["that's a wrap", "total views", "viewers who commented", "new followers", "how was your live experience",
                         "est. this live", "post highlights to attract", "tổng lượt xem", "người theo dõi mới", "tổng kết"],
    "layout_keywords": ["keep the layout", "layout, scene", "bố cục"],   # dòng chữ cạnh ô tick của hộp thoại Log out
    # --- BẤT KỲ thông báo/hộp thoại nào của TikTok che màn hình live -> đóng thông báo, tắt live, chờ, bật lại (như hạn chế 10 phút)
    "notice_enabled": True,
    "notice_idle_seconds": 90,          # thấy chuột bị dịch chuyển (người đang thao tác) thì tạm không coi hộp thoại là thông báo
    "notice_max_per_hour": 3,           # quá số lần này trong 1 giờ thì thôi (tránh tắt/bật live liên tục nếu có hộp thoại cứ hiện lại)
    "notice_button_labels": ["OK", "Got it", "Understood", "I understand", "Appeal", "Learn more", "Close", "Dismiss", "Confirm",
                             "Continue", "Later", "Not now", "Review", "Retry", "Try again", "Reconnect", "Agree", "Accept", "Update",
                             "Restart", "Done", "View details", "Đã hiểu", "Hiểu rồi", "Đóng", "Kháng nghị", "Tìm hiểu thêm", "Xác nhận",
                             "Tiếp tục", "Để sau", "Thử lại", "Kết nối lại", "Đồng ý", "Xem chi tiết", "Xong"],
    "notice_dismiss_labels": ["OK", "Got it", "Understood", "I understand", "Close", "Dismiss", "Later", "Not now", "Done",
                              "Đã hiểu", "Hiểu rồi", "Đóng", "Để sau", "Đồng ý", "Xong"],   # chỉ bấm các nút an toàn này để đóng thông báo
    "notice_skip_labels": ["End now", "End LIVE", "Go LIVE", "Log out", "Logout", "Pause LIVE", "Kết thúc LIVE", "Đăng xuất"],  # hộp thoại của chính Studio
    "notice_ignore_keywords": ["new version", "update available", "update now", "phiên bản mới", "bản cập nhật mới"],
    "notice_context_words": ["restrict", "suspend", "banned", "limited", "violat", "disabled", "hạn chế", "đình chỉ", "bị cấm",
                             "vi phạm", "tạm khóa", "giới hạn", "bị khóa"],   # có 1 trong các từ này + thời hạn >= 24 giờ thì mới coi là nặng
    "template_threshold": 0.85,
    "action_timeout_seconds": 25,
    # --- cập nhật nóng (xem updater.py): link tới file latest.json do bạn đặt; để trống = tắt
    "update_url": "",
    "auto_update": True,                # có bản mới thì tự cài khi rảnh (không đang xử lý cảnh báo)
    "update_check_hours": 6,
}

# thiết lập của các bản cũ không còn dùng / từ khóa cũ yếu hơn
_OBSOLETE = ("end_countdown_seconds", "auto_restart_live", "cancel_cooldown_seconds", "spam", "api", "hooks",
             "telegram", "account_name", "warning_keywords", "min_keyword_hits", "severe_keywords", "layout_keywords",
             "notice_button_labels", "notice_dismiss_labels", "notice_skip_labels", "notice_ignore_keywords", "notice_context_words",
             "severe_logout")


def deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _migrate(user):
    user = copy.deepcopy(user)
    for k in _OBSOLETE:
        user.pop(k, None)
    if user.get("check_interval_seconds") == 30:       # 30 giây là mặc định cũ (chưa ai chỉnh): dùng mặc định mới 10 giây
        user.pop("check_interval_seconds")
    labels = user.get("labels") or {}
    for k in ("ok", "save_layout_yes", "logged_out", "account"):
        labels.pop(k, None)
    user["config_version"] = CONFIG_VERSION
    return user


def save_config(cfg, path=None):
    p = Path(path) if path else CONFIG_PATH
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), "utf-8")
    tmp.replace(p)


def load_config(path=None):
    """Đọc config (thiếu khoá nào thì dùng mặc định). Lần đầu chạy / vừa nâng cấp từ bản cũ sẽ ghi lại file."""
    p = Path(path) if path else CONFIG_PATH
    user, migrated = {}, False
    if p.exists():
        try:
            user = json.loads(p.read_text("utf-8"))
        except Exception as e:
            log.warning("config.json lỗi (%s), dùng cấu hình mặc định", e)
            user = {}
        if user and int(user.get("config_version", 1) or 1) < CONFIG_VERSION:
            user, migrated = _migrate(user), True
    cfg = deep_merge(DEFAULTS, user)
    if migrated or not p.exists():
        save_config(cfg, p)
    return cfg


def setup_logging(extra_handler=None):
    log.setLevel(logging.INFO)
    log.propagate = False
    for h in list(log.handlers):
        log.removeHandler(h)
        h.close()
    fmt = logging.Formatter("%(asctime)s %(message)s", "%H:%M:%S")
    fh = logging.handlers.RotatingFileHandler(DATA / "guard.log", maxBytes=1_000_000, backupCount=2, encoding="utf-8")
    fh.setFormatter(fmt)
    log.addHandler(fh)
    if sys.stdout is not None:  # pythonw không có stdout
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        log.addHandler(sh)
    if extra_handler is not None:
        log.addHandler(extra_handler)


_mutex = None


def acquire_single_instance(wait=0):
    """Chỉ cho chạy 1 bản (tránh 2 bản cùng click vào Live Studio). Cùng tên với bản cũ và LiveCharacter.
    wait = số giây thử lại nếu bản cũ chưa kịp thoát (dùng sau khi tự cập nhật)."""
    global _mutex
    if sys.platform != "win32":
        return True
    k = ctypes.windll.kernel32
    k.CreateMutexW.restype = ctypes.c_void_p
    k.CloseHandle.argtypes = [ctypes.c_void_p]
    end = time.time() + wait
    while True:
        h = k.CreateMutexW(None, False, "Global\\TikTokGuardSingleton")
        if k.GetLastError() != 183:  # 183 = ERROR_ALREADY_EXISTS
            _mutex = h
            return True
        k.CloseHandle(h)
        if time.time() >= end:
            return False
        time.sleep(0.5)


def release_single_instance():
    """Nhả khoá 1-bản để tiến trình mới (sau cập nhật) khởi động được."""
    global _mutex
    if sys.platform == "win32" and _mutex:
        try:
            ctypes.windll.kernel32.CloseHandle(ctypes.c_void_p(_mutex))
        except Exception:
            pass
    _mutex = None


# --------------------------------------------------------------------------- xử lý chữ
def _ascii(s):
    """Bỏ dấu tiếng Việt (OCR của phần mềm trả chữ không dấu: 'đình chỉ' -> 'dinh chi')."""
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("đ", "d").replace("Đ", "D")


def norm(s):
    # bỏ hết khoảng trắng: OCR hay đọc dính chữ ("EndLIVE"), nhưng vẫn phân biệt "End LIVE?" (tiêu đề hộp thoại)
    return re.sub(r"\s+", "", _ascii(s).lower())


def compact(s):
    return re.sub(r"[\W_]+", "", _ascii(s).lower())


def plain(s):
    return re.sub(r"[\W_]+", " ", _ascii(s).lower()).strip()


def has_phrase(text, phrase):
    """Cụm từ có trong text không (không phân biệt khoảng trắng/dấu câu/dấu; số không dính vào số khác: '17 days' ≠ '7 days')."""
    chars = compact(phrase)
    if not chars:
        return False
    pat = r"\s*".join(re.escape(c) for c in chars)
    if chars[0].isdigit():
        pat = r"(?<![0-9])" + pat
    if chars[-1].isdigit():
        pat += r"(?![0-9])"
    return re.search(pat, plain(text)) is not None


_UNITS = {"min": 60, "hour": 3600, "hr": 3600, "day": 86400, "week": 604800, "month": 2592000,
          "phut": 60, "gio": 3600, "ngay": 86400, "tuan": 604800, "thang": 2592000}
# OCR hay đọc "10" thành "1o"/"1O"/"1l": chữ o/l/I chỉ được tính là số khi đứng sau một chữ số thật
_DUR = re.compile(r"(?<![0-9])([0-9][0-9oOlI]{0,2})\s*(min(?:ute)?s?|hours?|hrs?|days?|weeks?|months?|phut|gio|ngay|tuan|thang)", re.I)


def parse_duration(text):
    """Thời hạn đầu tiên ghi trong text ('for 10 minutes', '7 ngày'...) tính bằng giây, hoặc None."""
    for m in _DUR.finditer(_ascii(text)):
        num = int(m.group(1).translate(str.maketrans("oOlI", "0011")))
        unit = m.group(2).lower()
        for k, secs in _UNITS.items():
            if unit.startswith(k):
                return num * secs
    return None


def fmt_duration(secs):
    if not secs:
        return "?"
    secs = int(secs)
    if secs % 86400 == 0:
        return f"{secs // 86400} ngày"
    if secs % 3600 == 0:
        return f"{secs // 3600} giờ"
    if secs % 60 == 0:
        return f"{secs // 60} phút"
    return f"{secs} giây"


_TIMER = re.compile(r"^\W{0,2}[0-9OoIl|]{1,3}\s*[:;.]\s*[0-9OoIl|]{2}\s*[:;.]\s*[0-9OoIl|]{2}\W{0,2}$")
_FUZZY_KINDS = ("end_live", "go_live", "logout", "live_center")


@dataclass
class Item:
    text: str
    x0: float
    y0: float
    x1: float
    y1: float

    @property
    def cx(self):
        return (self.x0 + self.x1) / 2

    @property
    def cy(self):
        return (self.y0 + self.y1) / 2

    @property
    def h(self):
        return max(1.0, self.y1 - self.y0)


@dataclass
class Detection:
    kind: str             # "short" (10 phút...) | "severe" (7 ngày...)
    seconds: object       # thời hạn đọc được trong cảnh báo (giây) hoặc None
    text: str             # chữ quanh cảnh báo (để ghi nhật ký / chỉnh từ khóa)
    hits: int = 0


@dataclass
class Notice:
    """Hộp thông báo/hộp thoại của TikTok đang che màn hình live (khung chữ nằm giữa cửa sổ + hàng nút đặc bên dưới)."""
    text: str                  # chữ của hộp (đọc từ trên xuống)
    rect: tuple                # (x0, y0, x1, y1) trong ảnh chụp
    buttons: list              # [{"label", "pt" (toạ độ màn hình), "pink"}]
    pink: bool                 # có nút hồng chính của TikTok


ANCHOR_WORDS = ("suspend", "restrict", "gifting", "visibility", "inorganic", "hanche", "dinhchi", "tamdung", "tangqua")


def reading_order(items):
    """Sắp các dòng chữ theo thứ tự đọc (trên xuống dưới, trái sang phải)."""
    lines = []
    for it in sorted(items, key=lambda i: i.cy):
        if lines and abs(it.cy - lines[-1][0]) <= 0.6 * it.h:
            lines[-1][1].append(it)
        else:
            lines.append([it.cy, [it]])
    return [it for _, row in lines for it in sorted(row, key=lambda i: i.cx)]


def anchor_zone(anchors, items):
    """Những dòng chữ nằm trong khung của thông báo: nhóm các dòng 'anchor' gần nhau theo chiều dọc, lấy nhóm đông nhất
    rồi nới ra vài dòng. Mọi khoảng cách tính theo cỡ chữ nên không phụ thuộc độ phân giải màn hình."""
    anchors = sorted(anchors, key=lambda i: i.cy)
    groups, cur = [], [anchors[0]]
    for a in anchors[1:]:
        if a.cy - cur[-1].cy > 12 * max(a.h, cur[-1].h):
            groups.append(cur)
            cur = [a]
        else:
            cur.append(a)
    groups.append(cur)
    grp = max(groups, key=len)
    h = sorted(a.h for a in grp)[len(grp) // 2]
    y0, y1 = min(a.y0 for a in grp) - 3 * h, max(a.y1 for a in grp) + 3 * h
    x0, x1 = min(a.x0 for a in grp) - 6 * h, max(a.x1 for a in grp) + 6 * h
    return [i for i in items if x0 <= i.cx <= x1 and y0 <= i.cy <= y1]


# --------------------------------------------------------------------------- nhìn ảnh: ảnh đại diện, ô tick, nút hồng
def ui_scale():
    try:
        return ctypes.windll.user32.GetDpiForSystem() / 96.0
    except Exception:
        return 1.0


def bar_height(img):
    """Chiều cao vùng thanh tiêu đề (nơi có chuông / dấu ? / bánh răng / ảnh đại diện / nút thu nhỏ-đóng)."""
    return max(60, int(img.shape[0] * 0.075))


def detect_avatar(img):
    """Tâm ảnh đại diện (hình tròn đặc, nằm ngoài cùng bên phải thanh tiêu đề, trước nhóm nút thu nhỏ/phóng to/đóng).
    Biểu tượng chuông/?/bánh răng/nút cửa sổ chỉ là nét viền (rỗng) nên bị loại. None nếu không thấy."""
    import cv2
    import numpy as np
    H, W = img.shape[:2]
    bh = bar_height(img)
    x_off = W // 3
    gray = cv2.cvtColor(img[:bh, x_off:], cv2.COLOR_BGR2GRAY)
    bg = float(np.median(gray))
    mask = (np.abs(gray.astype(np.int16) - bg) > 22).astype(np.uint8) * 255
    k = max(3, (bh // 15) | 1)
    closed = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
    cnts, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    dmin, dmax = 0.24 * bh, 0.7 * bh
    best = None
    for c in cnts:
        x, y, w, h = cv2.boundingRect(c)
        if not (dmin <= w <= dmax and dmin <= h <= dmax and 0.8 <= w / h <= 1.25):
            continue
        area, per = cv2.contourArea(c), cv2.arcLength(c, True)
        if per == 0 or area < 0.6 * w * h or 4 * np.pi * area / per ** 2 < 0.8:
            continue
        if mask[y:y + h, x:x + w].mean() / 255.0 < 0.5:     # rỗng = biểu tượng nét viền, không phải ảnh
            continue
        cx, cy = x_off + x + w / 2, y + h / 2
        if best is None or cx > best[0]:
            best = (cx, cy)
    return best


def guess_avatar(img):
    """Ước lượng vị trí ảnh đại diện theo bố cục thanh tiêu đề (cách mép phải ~187 điểm ảnh ở 100% DPI). Chỉ là phương án cuối."""
    s = ui_scale()
    return img.shape[1] - 187 * s, 20 * s


def pink_mask(img):
    """Điểm ảnh màu hồng của TikTok (#FE2C55) - ô tick đã chọn và nút Log out."""
    b, g, r = img[..., 0].astype(int), img[..., 1].astype(int), img[..., 2].astype(int)
    return (r > 200) & (g < 120) & (b < 150)


def pink_button(img, x0, x1, y0, y1):
    """Nút chữ nhật hồng lớn nhất trong khung (x0..x1, y0..y1) -> tâm, hoặc None."""
    import cv2
    import numpy as np
    H, W = img.shape[:2]
    x0, x1, y0, y1 = max(0, int(x0)), min(W, int(x1)), max(0, int(y0)), min(H, int(y1))
    if x1 <= x0 or y1 <= y0:
        return None
    m = pink_mask(img[y0:y1, x0:x1]).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))      # chữ trắng trên nút làm thủng nút -> lấp lại
    n, _, stats, cents = cv2.connectedComponentsWithStats(m)
    best = None
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if w >= 40 and h >= 14 and 2.0 <= w / h <= 8.0 and (best is None or area > best[0]):
            best = (area, x0 + cents[i][0], y0 + cents[i][1])
    return (best[1], best[2]) if best else None


def solid_box(img, it, tol=8):
    """Nút phẳng (hình chữ nhật đặc 1 màu) bao quanh chữ `it`: (x0, y0, x1, y1, màu BGR) hoặc None.
    Màu nền nút = màu chiếm đa số trong các điểm ngay ngoài khung chữ; vùng cùng màu nối với nó phải vuông vức,
    cao 1,2-6 lần chữ (khung chữ của OCR lúc cao lúc thấp), đặc >= 78%, và có viền rõ (không tràn ra nền của hộp)."""
    import cv2
    import numpy as np
    H, W = img.shape[:2]
    h = it.h
    w = it.x1 - it.x0
    samples = []

    def px(a, b):
        a, b = int(round(a)), int(round(b))
        if 0 <= a < W and 0 <= b < H:
            samples.append(img[b, a].astype(int))

    for d in (3, 6, 9):
        px(it.x0 - d, it.cy)
        px(it.x1 + d, it.cy)
    for d in (2, 3, 4):                          # khung chữ của OCR đôi khi cao sát mép nút nên lấy cả mấy điểm gần
        px(it.cx, it.y0 - d)
        px(it.cx, it.y1 + d)
    if len(samples) < 6:
        return None
    arr = np.array(samples)
    near = [(np.abs(arr - a).max(axis=1) <= 6) for a in arr]
    k0 = int(np.argmax([m.sum() for m in near]))
    if near[k0].sum() < 5:
        return None
    med = np.median(arr[near[k0]], axis=0)
    bw, bh = int(max(300, 20 * h)), int(5 * h)
    rx0, rx1 = max(0, int(it.cx - bw)), min(W, int(it.cx + bw))
    ry0, ry1 = max(0, int(it.cy - bh)), min(H, int(it.cy + bh))
    roi = img[ry0:ry1, rx0:rx1]
    d = np.abs(roi.astype(int) - med.astype(int)).max(axis=2)
    m = (d <= tol).astype(np.uint8)
    k = max(5, int(0.5 * h) | 1)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))      # chữ làm thủng nút -> lấp lại
    n, lab, st, _ = cv2.connectedComponentsWithStats(m, connectivity=4)
    sx, sy = int(it.cx - rx0), int(it.cy - ry0)
    i = lab[min(max(sy, 0), lab.shape[0] - 1), min(max(sx, 0), lab.shape[1] - 1)]
    if i == 0:
        return None
    x, y, ww, hh, area = [int(v) for v in st[i]]
    if not (1.2 * h <= hh <= 6 * h and ww >= w + 0.8 * h and 1.3 <= ww / hh <= 14):
        return None
    if area < 0.78 * ww * hh:
        return None
    if not (x <= it.x0 - rx0 and x + ww >= it.x1 - rx0 and y <= it.y0 - ry0 and y + hh >= it.y1 - ry0):
        return None
    if x <= 0 or y <= 0 or x + ww >= roi.shape[1] or y + hh >= roi.shape[0] or ww > 560:
        return None                              # vùng cùng màu còn tràn ra ngoài khung quan sát: nền, không phải nút
    # nút phải có viền rõ: màu ngay NGOÀI hộp ở ít nhất 2 trong 4 cạnh khác màu nút (chữ trên nền phẳng như khung chat thì không)
    cx_, cy_ = x + ww // 2, y + hh // 2
    diff = 0
    for a, b in ((x - 3, cy_), (x + ww + 2, cy_), (cx_, y - 3), (cx_, y + hh + 2)):
        if 0 <= a < roi.shape[1] and 0 <= b < roi.shape[0] and np.abs(roi[b, a].astype(int) - med.astype(int)).max() >= 10:
            diff += 1
    if diff < 2:
        return None
    return rx0 + x, ry0 + y, rx0 + x + ww, ry0 + y + hh, tuple(int(c) for c in med)


# --------------------------------------------------------------------------- guard
def find_close_glyph(img, lc):
    """Biểu tượng X nhỏ (trắng trên nền tối) nằm bên phải chữ 'LIVE Center' của bảng tổng kết. Trả (x, y) tâm hoặc None.
    Chỉ tìm trong dải hẹp ngay bên phải chữ đó (không bao giờ chạm tới nút X đóng cả cửa sổ Studio ở thanh tiêu đề)."""
    import cv2
    import numpy as np
    H, W = img.shape[:2]
    h = lc.h
    xa, xb = int(lc.x1 + 0.5 * h), min(W, int(lc.x1 + 4.5 * h))
    ya, yb = max(0, int(lc.cy - 1.3 * h)), min(H, int(lc.cy + 1.3 * h))
    if xb - xa < 6 or yb - ya < 6:
        return None
    gray = cv2.cvtColor(img[ya:yb, xa:xb], cv2.COLOR_BGR2GRAY)
    mask = (gray > float(np.median(gray)) + 60).astype(np.uint8)
    n, _lab, stats, cent = cv2.connectedComponentsWithStats(mask, connectivity=8)
    best = None
    for i in range(1, n):
        x, y, w, hh, a = [int(v) for v in stats[i]]
        if 0.35 * h <= w <= 1.0 * h and 0.35 * h <= hh <= 1.0 * h and 0.7 <= w / hh <= 1.4 and 0.2 <= a / (w * hh) <= 0.7:
            cx_ = float(cent[i][0]) + xa
            if best is None or cx_ < best[0]:      # lấy cái gần chữ nhất (bên phải hơn có thể đã ra ngoài bảng)
                best = (cx_, float(cent[i][1]) + ya)
    return best


class Guard:
    def __init__(self, cfg, dry=False):
        self.cfg, self.dry = cfg, dry
        self.stop = threading.Event()
        self.running = False
        self.state, self.deadline = "monitoring", None
        self.suppress_until = 0.0
        self.last_check = None
        self.engine = None
        self.after_simulate = None
        self._last_err = 0.0
        self._quiet = {}
        self._mouse_pos, self._active_until = None, 0.0     # theo dõi chuột: người đang thao tác thì không coi hộp thoại là thông báo
        self._notice_times, self._notice_sigs = [], {}
        self._probe_block_until = 0.0        # sau mỗi lần "nhìn nhanh" kích hoạt đọc chữ thì nghỉ một lúc (nút hồng nằm lì không làm đọc chữ liên tục)
        self._live_seen_at = 0.0             # lần cuối thấy đồng hồ live (hộp thông báo che mất đồng hồ vẫn biết là đang live)
        self.handled = self._load_handled()

    # ---- tiện ích
    def notify(self, text):
        log.info(("[THỬ NGHIỆM] " if self.dry else "") + text)

    def log_once(self, key, text, every=600):
        """Ghi nhật ký tối đa 1 lần mỗi `every` giây cho cùng một lý do (khỏi tràn nhật ký khi chữ nằm lì trong khung chat)."""
        if time.time() - self._quiet.get(key, 0) >= every:
            self._quiet[key] = time.time()
            log.info(text)

    def status(self):
        left = 0
        if self.deadline and self.state == "waiting_restart":
            left = max(0, int(self.deadline - time.time()))
        return {"state": self.state, "seconds_left": left}

    def wait(self, seconds):
        """Chờ có thể ngắt bằng nút Dừng. True = chờ đủ, False = bị dừng giữa chừng."""
        if self.dry:
            seconds = min(seconds, 5)
        return not self.stop.wait(max(0, seconds))

    # ---- tin nhắn System đã xử lý (tin cũ còn nằm trong khung chat không được xử lý lại)
    def _load_handled(self):
        try:
            d = json.loads((DATA / "handled.json").read_text("utf-8"))
            now = time.time()
            return {k: v for k, v in d.items() if now - v < 86400}
        except Exception:
            return {}

    def _seen(self, sig):
        return bool(sig) and time.time() - self.handled.get(sig, 0) < 86400

    def _mark(self, sig):
        if not sig or self.dry:
            return
        self.handled[sig] = time.time()
        for k in sorted(self.handled, key=self.handled.get)[:-50]:
            self.handled.pop(k, None)
        try:
            (DATA / "handled.json").write_text(json.dumps(self.handled), "utf-8")
        except Exception:
            pass

    # ---- màn hình / OCR
    def studio_window(self):
        try:
            import pygetwindow as gw
            wins = [w for w in gw.getWindowsWithTitle(self.cfg["studio_window_title"]) if w.width > 300 and w.height > 300]
            return wins[0] if wins else None
        except Exception:
            return None

    def ocr(self, img):
        if self.engine is None:
            from rapidocr_onnxruntime import RapidOCR
            self.engine = RapidOCR()
        res, _ = self.engine(img)
        out = []
        for box, text, _score in res or []:
            xs, ys = [p[0] for p in box], [p[1] for p in box]
            out.append(Item(str(text), min(xs), min(ys), max(xs), max(ys)))
        return out

    def grab(self):
        """Chụp cửa sổ Live Studio (hoặc toàn màn hình nếu không thấy), CHƯA đọc chữ -> (img_bgr, left, top)."""
        import mss
        import numpy as np
        win = self.studio_window()
        with getattr(mss, "MSS", None) and mss.MSS() or mss.mss() as sct:   # mss 10+ đổi tên mss.mss -> mss.MSS
            mon = sct.monitors[0]
            region = mon
            if win is not None and not getattr(win, "isMinimized", False):
                l, t = max(win.left, mon["left"]), max(win.top, mon["top"])
                r = min(win.left + win.width, mon["left"] + mon["width"])
                b = min(win.top + win.height, mon["top"] + mon["height"])
                if r - l > 300 and b - t > 300:
                    region = {"left": l, "top": t, "width": r - l, "height": b - t}
            shot = sct.grab(region)
        img = np.ascontiguousarray(np.array(shot)[:, :, :3])  # BGR
        return img, region["left"], region["top"]

    def snap(self):
        """Chụp cửa sổ Live Studio + OCR -> (img_bgr, left, top, items)."""
        img, left, top = self.grab()
        return img, left, top, self.ocr(img)

    def fast_probe(self):
        """Nhìn nhanh, RẺ (không OCR): có nút hồng lớn nằm giữa màn hình không? Đó là dấu hiệu của hộp thoại TikTok vừa hiện ra
        (cả cảnh báo hạn chế lẫn thông báo khác) nên cần đọc chữ ngay thay vì chờ tới nhịp kiểm tra kế tiếp."""
        try:
            import cv2
            import numpy as np
            img, _l, _t = self.grab()
            H, W = img.shape[:2]
            if H < 300 or W < 400:
                return False
            m = pink_mask(img[int(0.15 * H):int(0.85 * H), int(0.2 * W):int(0.8 * W)]).astype(np.uint8)
            if int(m.sum()) < 400:
                return False
            m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))   # chữ trắng làm thủng nút -> lấp lại
            n, _lab, st, _c = cv2.connectedComponentsWithStats(m)
            sc = max(1.0, W / 1280.0)
            for i in range(1, n):
                x, y, w, h, a = [int(v) for v in st[i]]
                if w >= 60 * sc and h >= 20 * sc and 2.0 <= w / h <= 14 and a >= 0.7 * w * h:
                    return True
        except Exception:
            pass
        return False

    def save_debug(self, snap, name="debug_last.png"):
        """Lưu ảnh chụp: khung đỏ quanh chữ đọc được, vòng xanh ở các vị trí có thể là ảnh đại diện."""
        from PIL import Image, ImageDraw
        img, l, t, items = snap
        im = Image.fromarray(img[:, :, ::-1])
        d = ImageDraw.Draw(im)
        for it in items:
            d.rectangle([it.x0, it.y0, it.x1, it.y1], outline="red", width=2)
        try:
            for x, y, how in self.find_account(snap):
                d.ellipse([x - l - 14, y - t - 14, x - l + 14, y - t + 14], outline="lime", width=2)
        except Exception:
            pass
        path = DATA / name
        im.save(path)
        return path

    # ---- nhận diện cảnh báo
    def analyze(self, items):
        """None nếu không có cảnh báo, ngược lại Detection(kind='short'|'severe')."""
        cfg = self.cfg
        allc = compact(" ".join(i.text for i in items))
        hits = sum(1 for k in cfg["warning_keywords"] if compact(k) and compact(k) in allc)
        if hits == 0:
            return None
        anchors = [i for i in items if any(w in compact(i.text) for w in ANCHOR_WORDS)]
        near = anchor_zone(anchors, items) if anchors else list(items)
        ordered = reading_order(near)
        text = " ".join(i.text for i in ordered)
        # thời hạn chỉ lấy từ dòng cảnh báo đầu tiên trở xuống (<= 600 ký tự): chữ như "trong 3 ngày LIVE hôm nay" của khung
        # nhiệm vụ nằm phía trên không được tính là thời hạn hạn chế (nếu không 10 phút có thể bị hiểu nhầm thành 3 ngày -> đăng xuất!)
        first = next((k for k, i in enumerate(ordered) if any(w in compact(i.text) for w in ANCHOR_WORDS)), 0)
        dur_text = " ".join(i.text for i in ordered[first:])[:600]
        secs = parse_duration(dur_text)
        severe_kw = any(has_phrase(dur_text, k) for k in cfg["severe_keywords"])
        severe = secs >= cfg["severe_min_hours"] * 3600 if secs is not None else severe_kw
        # đủ từ khóa là nhận; riêng cảnh báo NẶNG (đăng xuất!) chỉ cần 1 từ khóa nếu có ghi rõ "7 ngày" quanh đó,
        # phòng khi TikTok đổi câu chữ. Cảnh báo ngắn thì luôn đòi đủ từ khóa để chat/bình luận không kích hoạt nhầm.
        if not (hits >= cfg["min_keyword_hits"] or severe):
            return None
        return Detection("severe" if severe else "short", secs, text, hits)

    def labelled(self, items, kind):
        labels = {norm(x) for x in self.cfg["labels"].get(kind, [])}
        out = [i for i in items if norm(i.text) in labels]
        if kind in _FUZZY_KINDS:
            # OCR hay dính biểu tượng đứng trước chữ ("U End LIVE", "II Pause LIVE", "-> Log out"): chấp nhận 1-2 ký tự thừa đứng TRƯỚC
            # nhãn và tách khỏi nhãn bằng khoảng trắng (hoặc toàn là ký hiệu). Không nhận "Send LIVE", "End LIVE?", "I want to End LIVE".
            pats = [re.compile(r"^(?:[^\w\s]{1,2}|\S{1,2}\s+)" + r"\s*".join(re.escape(c) for c in l) + "$", re.I) for l in labels if len(l) >= 6]
            for i in items:
                if not any(i is o for o in out) and any(p.match(_ascii(i.text).strip()) for p in pats):
                    out.append(i)
        return out

    def summary_hits(self, items):
        allc = compact(" ".join(i.text for i in items))
        return [k for k in self.cfg["summary_keywords"] if compact(k) and compact(k) in allc]

    def summary_candidates(self, snap):
        """Bảng tổng kết sau khi tắt live (Duration / Total views / New followers...). Trả [(x, y, cách)]: vị trí nút X của BẢNG,
        nằm cùng hàng, bên phải chữ 'LIVE Center' của bảng. Tuyệt đối không phải nút X đóng cả cửa sổ Studio. Không thấy bảng -> []."""
        img, l, t, items = snap
        if len(self.summary_hits(items)) < 2:
            return []
        kws = [compact(k) for k in self.cfg["summary_keywords"] if compact(k)]
        anchors = [i for i in items if compact(i.text).startswith("duration") or any(k in compact(i.text) for k in kws)]
        if not anchors:
            return []
        top = min(anchors, key=lambda i: i.cy)
        # 'LIVE Center' của BẢNG nằm ngay trên dòng đầu của bảng; 'LIVE Center' của thanh tiêu đề Studio xa hơn nên bị loại
        lcs = [i for i in self.labelled(items, "live_center") if 0 < top.cy - i.cy <= 2.2 * max(top.h, i.h)]
        if not lcs:
            return []
        lc = max(lcs, key=lambda i: i.cy)
        out = []
        try:
            gl = find_close_glyph(img, lc)
        except Exception:
            gl = None
        if gl:
            out.append((gl[0] + l, gl[1] + t, "tự nhận ra"))
        est = (lc.x1 + 2.05 * lc.h + l, lc.cy + t)
        if not out or (out[0][0] - est[0]) ** 2 + (out[0][1] - est[1]) ** 2 > 10 ** 2:
            out.append((est[0], est[1], "ước lượng theo chữ LIVE Center"))
        return out

    def dismiss_summary(self, wait=8):
        """Sau khi tắt live Studio hiện bảng tổng kết che nút Go LIVE (và che cả ảnh đại diện): phải bấm X của bảng.
        Chờ tối đa `wait` giây cho bảng hiện ra. True = đã thấy bảng và đóng được."""
        if self.dry:
            return False
        deadline, tries, warned = time.monotonic() + wait, 0, False
        while True:
            snap = self.snap()
            cands = self.summary_candidates(snap)
            if cands:
                if tries >= 4:
                    log.warning("Không đóng được bảng tổng kết sau khi tắt live. Hãy bấm X của bảng bằng tay.")
                    return False
                for x, y, how in cands:
                    tries += 1
                    self.click((x, y), f"X đóng bảng tổng kết ({how})")
                    time.sleep(1.2)
                    if not self.summary_candidates(self.snap()):
                        return True
                    if tries >= 4:
                        break
                continue
            if self.summary_hits(snap[3]) and not warned:      # thấy chữ của bảng nhưng không xác định được nút X
                warned = True
                log.warning("Thấy bảng tổng kết nhưng không tìm được nút X của bảng; thử nhấn ESC.")
                self.press_escape()
            if self.locate("go_live", snap) or time.monotonic() >= deadline:
                return False
            time.sleep(1.0)

    def find_timer(self, snap):
        """Đồng hồ đếm giờ live (vd 00:09:08) ở góc dưới bên phải thanh công cụ. Studio chỉ hiện menu End LIVE / Pause LIVE
        khi BẤM VÀO đồng hồ này. Lấy ô khớp nằm thấp nhất / phải nhất (bỏ giờ trong khung chat)."""
        img, l, t, items = snap
        H = img.shape[0]
        c = [i for i in items if _TIMER.match(i.text.strip()) and i.cy > 0.5 * H and i.h < 40]
        if not c:
            return None
        i = max(c, key=lambda i: (round(i.cy / 12), i.cx))
        return i.cx + l, i.cy + t

    def evidence(self, snap):
        """Bằng chứng đây là thông báo THẬT của TikTok chứ không phải bình luận của người xem:
        'popup' (hộp thoại có nút OK/Appeal), 'system' (tin nhắn của "System" trong khung chat) hoặc None."""
        items = snap[3]
        if self.find_ok(snap) is not None or self.labelled(items, "appeal"):
            return "popup"
        if self.labelled(items, "system"):
            return "system"
        return None

    def system_signature(self, snap, det):
        """Nhận dạng một tin nhắn System cụ thể (giờ gửi nằm cùng dòng với chữ 'System') để không xử lý lại khi nó còn trong khung chat."""
        hdr = self.labelled(snap[3], "system")
        if not hdr:
            return None
        h = hdr[0]
        ts = " ".join(i.text for i in snap[3] if i is not h and abs(i.cy - h.cy) <= 0.8 * h.h and i.x0 >= h.x1 - 5)
        digits = re.sub(r"\D", "", ts)
        return "ts:" + digits if len(digits) >= 3 else "tx:" + compact(det.text)[:80]

    # ---- BẤT KỲ hộp thông báo nào của TikTok che màn hình live
    def find_notice(self, snap):
        """Hộp thông báo/hộp thoại đang che màn hình live, hoặc None. Nhận ra theo HÌNH DẠNG chứ không theo nội dung:
        một hàng nút phẳng (nút hồng chính của TikTok và/hoặc nút kiểu OK / Got it / Appeal...) nằm dưới thân chữ, cả khung
        nằm giữa cửa sổ trên nền phẳng 1 màu. Không phụ thuộc ngôn ngữ hay câu chữ của thông báo."""
        import numpy as np
        img, l, t, items = snap
        H, W = img.shape[:2]
        cfg = self.cfg
        if H < 300 or W < 400 or not items:
            return None
        if len(self.summary_hits(items)) >= 2 or self.logout_dialog(snap):
            return None                          # bảng tổng kết sau live / hộp thoại Log out là việc của Studio, không phải thông báo
        vocab = {norm(x) for x in cfg["notice_button_labels"]}
        skip = {norm(x) for x in cfg["notice_skip_labels"]}

        def lab_key(text):
            k = norm(text)
            return k.replace("0", "o") if len(k) <= 4 else k

        boxes = []
        for it in items:
            if len(it.text) > 28 or _TIMER.match(it.text.strip()):
                continue
            b = solid_box(img, it)
            if b is None or any(abs(b[0] - o[1][0]) < 4 and abs(b[1] - o[1][1]) < 4 for o in boxes):
                continue
            boxes.append((it, b))
        rows = []
        for it, b in sorted(boxes, key=lambda x: x[1][1] + x[1][3]):
            cy, bh = (b[1] + b[3]) / 2, b[3] - b[1]
            for r in rows:
                if abs(r["cy"] - cy) <= 0.6 * max(bh, r["bh"]):
                    r["b"].append((it, b))
                    break
            else:
                rows.append({"cy": cy, "bh": bh, "b": [(it, b)]})
        best = None
        for r in rows:
            bx0, bx1 = min(b[0] for _i, b in r["b"]), max(b[2] for _i, b in r["b"])
            by0, by1 = min(b[1] for _i, b in r["b"]), max(b[3] for _i, b in r["b"])
            inbtn = lambda i: any(b[0] - 2 <= i.cx <= b[2] + 2 and b[1] - 2 <= i.cy <= b[3] + 2 for _i, b in r["b"])
            span = bx1 - bx0
            cand = sorted([i for i in items if not inbtn(i) and i.cy < by0 and bx0 - 0.05 * span - 20 <= i.cx <= bx1 + 0.05 * span + 20],
                          key=lambda i: -i.cy)
            foot = self._side_color(img, Item("", bx0 - 2, (by0 + by1) / 2 - 1, bx1 + 2, (by0 + by1) / 2 + 1))   # nền hộp ngay cạnh hàng nút
            lines, top, body_bg = [], by0, None
            for i in cand:                       # chuỗi dòng chữ liên tục đi lên từ hàng nút, cùng màu nền với thân hộp
                if top - i.y1 > (4.5 if not lines else 3.0) * max(i.h, 12):
                    break
                bgc = self._side_color(img, i)
                if bgc is not None:
                    if foot is not None and np.abs(bgc - foot).max() > 20:
                        continue                 # chữ nằm trên nền khác hẳn nền hộp (chat / cảnh phát phía sau hộp)
                    if body_bg is None:
                        body_bg = bgc
                    elif np.abs(bgc - body_bg).max() > 8:
                        break                    # đã ra khỏi hộp
                lines.append(i)
                top = min(top, i.y0)
            if not lines:
                continue
            text = " ".join(i.text for i in sorted(lines, key=lambda i: (round(i.cy / 8), i.x0)))
            if len(compact(text)) < 15:
                continue
            rx0, rx1 = max(0, int(min(bx0, min(i.x0 for i in lines)) - 10)), min(W, int(max(bx1, max(i.x1 for i in lines)) + 10))
            ry0, ry1 = max(0, int(min(i.y0 for i in lines) - 12)), min(H, int(by1 + 12))
            cw, ch = rx1 - rx0, ry1 - ry0
            if cw < max(200, 0.18 * W) or ch < 90:
                continue
            if abs((rx0 + rx1) / 2 - W / 2) > 0.2 * W or abs((ry0 + ry1) / 2 - H / 2) > 0.3 * H:
                continue                         # hộp thoại luôn nằm giữa cửa sổ
            if abs((bx0 + bx1) / 2 - (rx0 + rx1) / 2) > 0.25 * cw:
                continue                         # hàng nút phải nằm giữa hộp (không phải nút lẻ ở một góc)
            reg = img[ry0:ry1, rx0:rx1].astype(int)
            q = (reg // 6).reshape(-1, 3)
            keys, counts = np.unique(q[:, 0] * 65536 + q[:, 1] * 256 + q[:, 2], return_counts=True)
            kk = int(keys[counts.argmax()])
            dom = np.array([kk // 65536, (kk // 256) % 256, kk % 256]) * 6 + 3
            if (np.abs(reg - dom).max(axis=2) <= 24).mean() < 0.5:
                continue                         # nền không phẳng = hình ảnh/cảnh phát, không phải hộp thoại
            btns = []
            for it, b in r["b"]:
                bb, gg, rr = b[4]
                btns.append({"label": it.text, "pt": ((b[0] + b[2]) / 2 + l, (b[1] + b[3]) / 2 + t), "pink": rr > 200 and gg < 120 and bb < 150})
            if any(lab_key(b["label"]) in skip for b in btns):
                continue                         # hộp thoại do chính Studio mở (End now, Log out...)
            pink = any(b["pink"] for b in btns)
            if not (pink or any(lab_key(b["label"]) in vocab for b in btns)):
                self.log_once("notice-unknown", "Thấy một hộp có hàng nút nhưng nhãn nút lạ (%s) và không có nút hồng nên bỏ qua." %
                              ", ".join(b["label"] for b in btns), 3600)
                continue
            n = Notice(text, (rx0, ry0, rx1, ry1), btns, pink)
            if best is None or len(compact(n.text)) > len(compact(best.text)):
                best = n
        return best

    @staticmethod
    def _side_color(img, it):
        """Màu nền ngay bên trái/phải một dòng chữ (None nếu ra ngoài ảnh)."""
        import numpy as np
        H, W = img.shape[:2]
        pts = []
        for a in (it.x0 - 6, it.x1 + 6):
            a, b = int(a), int(it.cy)
            if 1 <= a < W - 1 and 1 <= b < H - 1:
                pts.append(img[b - 1:b + 2, a - 1:a + 2].reshape(-1, 3).mean(0))
        return np.median(np.array(pts), axis=0) if pts else None

    def notice_severity(self, text):
        """('severe'|'short', số giây hoặc None). Nặng (đăng xuất) CHỈ khi vừa có từ nói về hạn chế/vi phạm vừa có thời hạn >= 24 giờ
        (vd 7 ngày): một thông báo bình thường có chữ '7 days' không làm đăng xuất."""
        cfg = self.cfg
        secs = parse_duration(text)
        longer = (secs is not None and secs >= cfg["severe_min_hours"] * 3600) or any(has_phrase(text, k) for k in cfg["severe_keywords"])
        ctx = any(len(compact(w)) >= 5 and compact(w) in compact(text) for w in cfg["notice_context_words"])
        if longer and ctx:
            return "severe", secs
        return "short", (secs if secs and secs < cfg["severe_min_hours"] * 3600 else None)

    def mouse_pos(self):
        try:
            import pyautogui
            p = pyautogui.position()
            return int(p[0]), int(p[1])
        except Exception:
            return None

    def user_active(self):
        """Chuột bị dịch chuyển giữa 2 lần kiểm tra (không phải do phần mềm bấm) = có người đang thao tác trên máy."""
        now = time.time()
        pos = self.mouse_pos()
        if pos is not None:
            if self._mouse_pos is not None and abs(pos[0] - self._mouse_pos[0]) + abs(pos[1] - self._mouse_pos[1]) > 3:
                self._active_until = now + self.cfg["notice_idle_seconds"]
            self._mouse_pos = pos
        return now < self._active_until

    @staticmethod
    def own_window_active():
        """Cửa sổ đang ở trên cùng là của chính TikTok Guard (hộp thoại Yes/No, OK của phần mềm này) -> không phải thông báo của TikTok."""
        try:
            u = ctypes.windll.user32
            u.GetForegroundWindow.restype = ctypes.c_void_p
            u.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
            pid = ctypes.c_ulong(0)
            u.GetWindowThreadProcessId(u.GetForegroundWindow(), ctypes.byref(pid))
            return pid.value == os.getpid()
        except Exception:
            return False

    def dismiss_notice(self, snap, n):
        """Đóng thông báo bằng cách AN TOÀN: chỉ bấm nút kiểu OK / Got it / Close...; không có nút như vậy (hoặc bấm không được) thì ESC.
        Không bao giờ bấm nút lạ (Update, Restart, Confirm...) vì không biết nó làm gì. True = hộp đã biến mất."""
        dis = {norm(x) for x in self.cfg["notice_dismiss_labels"]}
        cur = n
        for attempt in range(3):
            safe = [b for b in cur.buttons if norm(b["label"]) in dis or (len(norm(b["label"])) <= 4 and norm(b["label"]).replace("0", "o") in dis)]
            if safe and attempt != 1:
                pick = max(safe, key=lambda b: (b["pink"], b["pt"][0]))
                self.click(pick["pt"], f"{pick['label']} (đóng thông báo)")
            else:
                log.info("Đóng thông báo bằng phím ESC%s", " [dry-run]" if self.dry else "")
                self.press_escape()
            if self.dry:
                return True
            time.sleep(1.0)
            snap = self.snap()
            cur = self.find_notice(snap)
            if cur is None:
                return True
        log.warning("Không đóng được thông báo (nút thấy: %s). Vẫn tiếp tục tắt live.", ", ".join(b["label"] for b in n.buttons))
        try:
            self.save_debug(snap, "last_notice.png")
        except Exception:
            pass
        return False

    def check_notice(self, snap):
        """Không có cảnh báo hạn chế nào nhưng có hộp thông báo che màn hình live -> xử lý như hạn chế ngắn (hoặc nặng nếu ghi >= 24 giờ)."""
        cfg = self.cfg
        if not cfg.get("notice_enabled", True):
            return
        if self.user_active():
            return
        n = self.find_notice(snap)
        if n is None:
            return
        if self.own_window_active():
            self.log_once("notice-own", "Bỏ qua: hộp thoại đang hiện là của chính TikTok Guard.", 3600)
            return
        if any(has_phrase(n.text, k) for k in cfg["notice_ignore_keywords"]):
            self.log_once("notice-ignore", "Bỏ qua thông báo thuộc danh sách bỏ qua: " + n.text[:120], 3600)
            return
        now = time.time()
        if not self.find_timer(snap) and now - self._live_seen_at > 900:
            self.log_once("notice-offline", "Thấy hộp thông báo nhưng không thấy live đang chạy (không thấy đồng hồ live trong 15 phút qua) nên không làm gì.", 3600)
            return
        self._notice_times = [x for x in self._notice_times if now - x < 3600]
        if len(self._notice_times) >= int(cfg["notice_max_per_hour"]):
            self.log_once("notice-storm", f"Đã xử lý {len(self._notice_times)} thông báo trong 1 giờ qua, tạm không xử lý thêm (tránh tắt/bật live liên tục). "
                                         "Thông báo hiện tại: " + n.text[:120], 1800)
            return
        sig = "nt:" + compact(n.text)[:60]
        if now - self._notice_sigs.get(sig, 0) < 1800:
            self.log_once("notice-dup", "Bỏ qua: thông báo này vừa được xử lý (còn hiện): " + n.text[:80], 900)
            return
        log.info("Phát hiện thông báo của TikTok che màn hình live (nút: %s). Chữ: %s",
                 ", ".join(b["label"] for b in n.buttons), n.text[:400])
        try:
            self.save_debug(snap, "last_notice.png")
        except Exception:
            pass
        time.sleep(self.cfg["confirm_delay_seconds"])      # xác nhận lần 2
        snap2 = self.snap()
        n2 = self.find_notice(snap2)
        if n2 is None:
            log.info("Thông báo đã biến mất ngay sau khi thấy, bỏ qua.")
            return
        k1, _s1 = self.notice_severity(n.text)
        k2, s2 = self.notice_severity(n2.text)
        kind = "severe" if k1 == k2 == "severe" else "short"
        self._notice_sigs[sig] = now
        self._notice_times.append(now)
        self.handle_warning(kind, snap2, s2, notice=n2,
                            reason="Có thông báo của TikTok che màn hình live: " + n2.text[:140])

    def template_match(self, kind, img):
        p = TEMPLATES / f"{kind}.png"
        if not p.exists():
            return None
        import cv2
        tpl = cv2.imread(str(p), cv2.IMREAD_GRAYSCALE)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        if tpl is None or tpl.shape[0] > gray.shape[0] or tpl.shape[1] > gray.shape[1]:
            return None
        _, mx, _, loc = cv2.minMaxLoc(cv2.matchTemplate(gray, tpl, cv2.TM_CCOEFF_NORMED))
        if mx < self.cfg["template_threshold"]:
            return None
        return loc[0] + tpl.shape[1] / 2, loc[1] + tpl.shape[0] / 2

    def locate(self, kind, snap, near_center=False, exclude=None):
        """Toạ độ màn hình của nút theo nhãn OCR (rồi tới ảnh mẫu templates/<kind>.png nếu bạn có đặt)."""
        img, l, t, items = snap
        pts = [(i.cx + l, i.cy + t) for i in self.labelled(items, kind)]
        if not pts:
            tp = self.template_match(kind, img)
            pts = [(tp[0] + l, tp[1] + t)] if tp else []
        if exclude:
            pts = [p for p in pts if (p[0] - exclude[0]) ** 2 + (p[1] - exclude[1]) ** 2 > 50 ** 2]
        if near_center:  # hộp thoại thường nằm giữa cửa sổ
            cx, cy = l + img.shape[1] / 2, t + img.shape[0] / 2
            pts.sort(key=lambda p: (p[0] - cx) ** 2 + (p[1] - cy) ** 2)
        return pts[0] if pts else None

    def find_ok(self, snap):
        """Nút OK của hộp cảnh báo (ưu tiên nút nằm cạnh nút Appeal)."""
        img, l, t, items = snap
        oks = self.labelled(items, "ok")
        appeal = self.labelled(items, "appeal")
        if oks and appeal:
            ref = appeal[0]
            oks.sort(key=lambda i: abs(i.cy - ref.cy) + abs(i.cx - ref.cx) * 0.1)
        if oks:
            return oks[0].cx + l, oks[0].cy + t
        tp = self.template_match("ok", img)
        return (tp[0] + l, tp[1] + t) if tp else None

    # ---- đăng xuất: ảnh đại diện -> menu -> hộp thoại Log out
    def find_account(self, snap):
        """Các vị trí có thể bấm để mở menu tài khoản, theo độ tin cậy: ảnh mẫu account.png, tự nhận ra, ước lượng."""
        img, l, t, _items = snap
        cands = []
        tp = self.template_match("account", img)
        if tp:
            cands.append((tp[0] + l, tp[1] + t, "ảnh mẫu"))
        try:
            av = detect_avatar(img)
        except Exception:
            av = None
        if av:
            cands.append((av[0] + l, av[1] + t, "tự nhận ra"))
        gx, gy = guess_avatar(img)
        cands.append((gx + l, gy + t, "ước lượng theo bố cục"))
        out = []
        for c in cands:
            if all((c[0] - o[0]) ** 2 + (c[1] - o[1]) ** 2 > 12 ** 2 for o in out):
                out.append(c)
        return out

    def logout_dialog(self, snap):
        """(dòng 'Keep the layout...', nút Cancel) nếu đang hiện hộp thoại 'Log out of ...?', ngược lại None."""
        items = snap[3]
        kws = [compact(k) for k in self.cfg["layout_keywords"] if compact(k)]
        keep = [i for i in items if any(k in compact(i.text) for k in kws)]
        cancel = self.labelled(items, "cancel")
        if keep and cancel:
            return min(keep, key=lambda i: i.cy), cancel[0]
        return None

    @staticmethod
    def checkbox_box(keep):
        """Ô tick nằm ngay bên trái dòng chữ: (tâm x, tâm y, nửa cạnh), đo theo cỡ chữ."""
        h = keep.h
        return keep.x0 - 1.04 * h, keep.cy, 0.7 * h

    def checkbox_state(self, img, keep):
        """'checked' | 'unchecked' | 'unknown' theo tỉ lệ điểm ảnh hồng trong ô tick."""
        cx, cy, r = self.checkbox_box(keep)
        H, W = img.shape[:2]
        x0, x1, y0, y1 = max(0, int(cx - r)), min(W, int(cx + r)), max(0, int(cy - r)), min(H, int(cy + r))
        if x1 - x0 < 4 or y1 - y0 < 4:
            return "unknown"
        share = float(pink_mask(img[y0:y1, x0:x1]).mean())
        return "checked" if share >= 0.45 else "unchecked" if share < 0.08 else "unknown"

    def logout_button(self, snap, keep, cancel):
        """Nút Log out xác nhận của hộp thoại: theo chữ, không thấy chữ thì theo nút hồng lớn nằm dưới dòng 'Keep the layout'."""
        img, l, t, items = snap
        labels = {norm(x) for x in self.cfg["labels"]["logout"]}
        cands = [i for i in items if norm(i.text) in labels and i.cy > keep.cy]
        if cands:
            b = min(cands, key=lambda i: abs(i.cy - cancel.cy))
            return b.cx + l, b.cy + t
        h = keep.h
        pb = pink_button(img, keep.x0 - 8 * h, keep.x1 + 8 * h, keep.cy, keep.cy + 14 * h)
        return (pb[0] + l, pb[1] + t) if pb else None

    def live_ui(self, snap):
        """Còn thấy đồng hồ live / nút End LIVE / Go LIVE (tức vẫn ở giao diện live, chưa đăng xuất)."""
        return bool(self.labelled(snap[3], "end_live") or self.labelled(snap[3], "go_live") or self.find_timer(snap))

    # ---- thao tác chuột
    def click(self, pt, what):
        log.info("click %s tại %s%s", what, (int(pt[0]), int(pt[1])), " [dry-run]" if self.dry else "")
        if self.dry:
            return
        import pyautogui
        pyautogui.moveTo(pt[0], pt[1], duration=0.25)
        pyautogui.click()
        self._mouse_pos = self.mouse_pos()       # chuột do chính phần mềm dời không bị tính là "người đang thao tác"

    def press_escape(self):
        if not self.dry:
            import pyautogui
            pyautogui.press("esc")

    def focus_studio(self):
        win = self.studio_window()
        if win is None:
            raise RuntimeError("Không thấy cửa sổ TikTok LIVE Studio")
        try:
            if win.isMinimized:
                win.restore()
            win.activate()
        except Exception:
            try:
                import pyautogui
                pyautogui.press("alt")
                win.activate()
            except Exception:
                log.warning("Không đưa được Live Studio lên trước")
        time.sleep(0.8)

    @contextlib.contextmanager
    def restore_focus(self):
        prev = None
        try:
            import pygetwindow as gw
            prev = gw.getActiveWindow()
        except Exception:
            pass
        try:
            yield
        finally:
            try:
                if prev is not None:
                    prev.activate()
            except Exception:
                pass

    def end_live(self):
        """Trả về 'ended' | 'already_off' | 'fail'.
        Thanh công cụ dưới của Live Studio chỉ có biểu tượng: phải BẤM VÀO ĐỒNG HỒ đếm giờ live (góc dưới bên phải)
        thì mới hiện menu 'End LIVE' / 'Pause LIVE'. Bấm End LIVE, rồi xác nhận nếu Studio hỏi lại. Không bao giờ bấm Pause LIVE."""
        if self.dry:
            try:
                snap = self.snap()
                log.info("[dry-run] đồng hồ live: %s · menu End LIVE đang mở: %s -> thật sẽ bấm đồng hồ, bấm End LIVE, rồi xác nhận",
                         self.find_timer(snap) or "KHÔNG thấy", self.locate("end_live", snap) or "không")
            except Exception as e:
                log.info("[dry-run] bỏ qua bước End LIVE (%s)", e)
            return "ended"
        timeout = self.cfg["action_timeout_seconds"]
        with self.restore_focus():
            self.focus_studio()
            snap = self.snap()
            end_pt = self.locate("end_live", snap)           # menu đã mở sẵn
            if not end_pt:
                tm = self.find_timer(snap)
                if not tm:
                    return "already_off" if self.locate("go_live", snap) else "fail"
                for _attempt in range(2):
                    self.click(tm, "đồng hồ live (mở menu End LIVE)")
                    for _ in range(3):
                        time.sleep(1.0)
                        snap = self.snap()
                        end_pt = self.locate("end_live", snap)
                        if end_pt:
                            break
                    if end_pt:
                        break
                    self.press_escape()                        # menu không mở: đóng thứ có thể đang mở rồi thử lại
                    time.sleep(0.5)
                    tm = self.find_timer(self.snap()) or tm
                if not end_pt:
                    log.warning("Bấm đồng hồ live nhưng không thấy menu End LIVE. Xem ảnh debug_last.png trong thư mục dữ liệu.")
                    self.save_debug(snap, "debug_last.png")
                    return "fail"
            self.click(end_pt, "End LIVE")
            confirms, gone, deadline = 0, 0, time.monotonic() + timeout
            while time.monotonic() < deadline:
                time.sleep(1.0)
                snap = self.snap()
                timer = self.find_timer(snap)
                if self.locate("go_live", snap) and not timer:
                    return "ended"
                if self.summary_candidates(snap):                # bảng tổng kết hiện ra = live đã tắt
                    self.dismiss_summary(wait=0)
                    return "ended"
                pt = self.locate("confirm_end", snap, near_center=True, exclude=end_pt)
                if pt and confirms < 3:
                    confirms += 1
                    gone = 0
                    self.click(pt, "xác nhận kết thúc")
                    time.sleep(2)
                    continue
                if timer or self.locate("end_live", snap):
                    gone = 0
                else:                                          # hết đồng hồ + không còn hộp thoại xác nhận 2 lần liền = live đã tắt
                    gone += 1
                    if gone >= 2:
                        self.dismiss_summary()                 # bảng tổng kết có thể hiện chậm vài giây
                        return "ended"
            self.save_debug(snap, "debug_last.png")
        return "fail"

    def go_live(self):
        if self.dry:
            log.info("[dry-run] bỏ qua bước Go LIVE")
            return True
        with self.restore_focus():
            self.focus_studio()
            clicks, deadline = 0, time.monotonic() + self.cfg["action_timeout_seconds"] + 20
            while time.monotonic() < deadline:
                snap = self.snap()
                if self.find_timer(snap) or self.locate("end_live", snap):  # đã live (đồng hồ đếm giờ hiện)
                    return True
                if self.summary_candidates(snap):               # bảng tổng kết của lần live trước còn che nút Go LIVE
                    self.dismiss_summary(wait=0)
                    continue
                pt = self.locate("go_live", snap)
                if pt and clicks < 3:
                    clicks += 1
                    self.click(pt, "Go LIVE")
                time.sleep(3)
        return False

    def go_live_retry(self, tries=3, gap=20):
        for i in range(tries):
            if self.go_live():
                return True
            if i < tries - 1 and not self.wait(gap):
                return False
        return False

    def logout(self):
        """Đăng xuất: bấm ảnh đại diện -> 'Log out' -> hộp thoại giữ nguyên ô tick 'Keep the layout...' -> bấm Log out.
        Trả về 'ok' | 'unverified' (đã bấm nhưng không xác nhận được) | 'fail' (không mở được menu / không thấy Log out)."""
        timeout = self.cfg["action_timeout_seconds"]
        with self.restore_focus():
            if not self.dry:
                self.focus_studio()
            snap = self.snap()
            if not self.dry and self.summary_candidates(snap):      # bảng tổng kết che thanh tiêu đề: đóng trước
                self.dismiss_summary(wait=0)
                snap = self.snap()
            dlg = self.logout_dialog(snap)
            if self.dry:                      # chỉ báo sẽ bấm ở đâu, không bấm
                if dlg:
                    keep, cancel = dlg
                    log.info("[dry-run] đang hiện hộp thoại Log out: ô tick '%s', sẽ bấm Log out tại %s",
                             self.checkbox_state(snap[0], keep), self.logout_button(snap, keep, cancel))
                elif self.locate("logout", snap):
                    self.click(self.locate("logout", snap), "Log out (menu)")
                else:
                    for x, y, how in self.find_account(snap):
                        self.click((x, y), f"ảnh đại diện ({how})")
                return "ok"
            if not dlg:
                pt = self.locate("logout", snap)
                if not pt:                    # menu chưa mở -> bấm ảnh đại diện (thử lần lượt các vị trí, kiểm tra bằng việc thấy 'Log out')
                    for x, y, how in self.find_account(snap):
                        self.click((x, y), f"ảnh đại diện ({how})")
                        time.sleep(1.2)
                        s2 = self.snap()
                        pt = self.locate("logout", s2)
                        if pt:
                            break
                        self.press_escape()
                        time.sleep(0.5)
                if not pt:
                    log.warning("Không mở được menu tài khoản / không thấy mục Log out. Xem ảnh debug_last.png trong thư mục dữ liệu.")
                    return "fail"
                self.click(pt, "Log out (menu)")
            logout_clicks, ticks, confirmed = 1, 0, 0
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                time.sleep(1.5)
                snap = self.snap()
                dlg = self.logout_dialog(snap)
                if dlg:
                    keep, cancel = dlg
                    st = self.checkbox_state(snap[0], keep)
                    if st == "unchecked" and ticks < 2:      # "Keep the layout..." phải được tick
                        ticks += 1
                        cx, cy, _r = self.checkbox_box(keep)
                        self.click((cx + snap[1], cy + snap[2]), "ô tick 'Keep the layout...'")
                        time.sleep(0.6)
                        continue
                    if st == "unknown":
                        log.warning("Không xác định được ô tick 'Keep the layout...' đã chọn hay chưa, giữ nguyên.")
                    btn = self.logout_button(snap, keep, cancel)
                    if btn and confirmed < 3:
                        confirmed += 1
                        self.click(btn, "Log out (xác nhận, giữ layout)")
                        time.sleep(2)
                    continue
                if not self.live_ui(snap):
                    return "ok"               # không còn nút End/Go LIVE và không còn hộp thoại: đã ra khỏi giao diện live
                lg = self.locate("logout", snap)
                if lg and logout_clicks < 3:  # menu còn mở: lần bấm trước chưa ăn
                    logout_clicks += 1
                    self.click(lg, "Log out (menu, lần %d)" % logout_clicks)
        return "ok" if confirmed else "unverified"

    # ---- luồng chính
    def check_once(self):
        if time.time() < self.suppress_until:
            return
        snap = self.snap()
        self.last_check = time.time()
        if self.find_timer(snap):
            self._live_seen_at = time.time()
        det = self.analyze(snap[3])
        if det is None:
            return self.check_notice(snap)
        ev = self.evidence(snap)
        if ev == "system" and self._seen(self.system_signature(snap, det)):
            self.log_once("old-system", "Bỏ qua: tin nhắn System này đã xử lý rồi (còn nằm trong khung chat).")
            return
        log.info("Phát hiện cảnh báo (%s, thời hạn đọc được: %s, bằng chứng: %s). Chữ quanh cảnh báo: %s",
                 "NẶNG" if det.kind == "severe" else "ngắn", fmt_duration(det.seconds), ev or "không có", det.text[:400])
        try:
            self.save_debug(snap, "last_warning.png")
        except Exception:
            pass
        time.sleep(self.cfg["confirm_delay_seconds"])      # xác nhận lần 2 cho chắc rồi mới thao tác
        snap2 = self.snap()
        det2 = self.analyze(snap2[3])
        if det2 is None:
            log.info("Cảnh báo đã biến mất ngay sau khi thấy, bỏ qua.")
            return
        ev2 = self.evidence(snap2)
        if ev2 is None:
            self.suppress_until = time.time() + 60
            self.log_once("no-evidence", "Thấy chữ giống cảnh báo nhưng không thấy nút OK/Appeal và không phải tin nhắn của "
                                         "'System' nên bỏ qua (có thể là bình luận trong chat).")
            return
        sig = self.system_signature(snap2, det2)
        if ev2 == "system" and self._seen(sig):
            self.log_once("old-system", "Bỏ qua: tin nhắn System này đã xử lý rồi (còn nằm trong khung chat).")
            return
        self._mark(sig)              # đánh dấu trước khi làm để tin này (nằm lì trong chat) không bị xử lý lại
        kind = "severe" if det.kind == det2.kind == "severe" else "short"   # lệch nhau thì chọn việc nhẹ hơn
        self.handle_warning(kind, snap2, det2.seconds)

    def handle_warning(self, kind, snap=None, seconds=None, notice=None, reason=None):
        if notice is not None:
            self.dismiss_notice(snap, notice)
            time.sleep(0.5 if self.dry else 1.0)
        elif snap is not None:
            pt = self.find_ok(snap)
            if pt:
                self.click(pt, "OK (đóng cảnh báo)")
                time.sleep(0.8)
            else:
                log.info("Không có nút OK để bấm (cảnh báo dạng tin nhắn trong chat).")
        if kind == "severe":
            self.handle_severe(reason, seconds)
        else:
            self.handle_short(seconds, reason)

    def handle_short(self, seconds=None, reason=None):
        """Hạn chế ngắn (10 phút): tắt live -> chờ -> bật lại."""
        delay = self.cfg["restart_delay_seconds"]
        if seconds and 0 < seconds < self.cfg["severe_min_hours"] * 3600:
            delay = max(delay, int(seconds))     # cảnh báo ghi lâu hơn mặc định thì chờ đủ thời hạn đó
        if reason:
            self.notify(f"⚠️ {reason}. Đang tắt live, sẽ bật lại sau {fmt_duration(delay)}.")
        else:
            self.notify(f"⚠️ LIVE bị hạn chế hiển thị {fmt_duration(seconds or delay)}. Đang tắt live, sẽ bật lại sau {fmt_duration(delay)}.")
        self.state = "ending"
        res = self.end_live()
        if res == "already_off":
            self.notify("ℹ️ Live đang tắt sẵn nên không tự bật lại.")
        elif res != "ended":
            self.notify("❌ Không tắt được live (không thấy nút/hộp thoại). Hãy kiểm tra thủ công.")
        if res != "ended":
            self.suppress_until = time.time() + 120
            self.state = "monitoring"
            return
        self._live_seen_at = 0.0
        back = time.strftime("%H:%M", time.localtime(time.time() + delay))
        self.notify(f"⏹ Đã tắt live. Bật lại lúc khoảng {back}.")
        self.state, self.deadline = "waiting_restart", time.time() + delay
        if not self.wait(delay):
            self.notify("↩️ Đã dừng theo dõi nên không bật lại live. Hãy bật thủ công khi sẵn sàng.")
            self.state = "monitoring"
            return
        self.state = "going_live"
        ok = self.go_live_retry()
        if ok:
            self._live_seen_at = time.time()
        self.notify("▶️ Đã bật lại live." if ok else "❌ Không bật lại được live. Hãy bấm Go LIVE thủ công.")
        self.suppress_until = time.time() + 60
        self.state = "monitoring"

    def handle_severe(self, reason=None, seconds=None):
        """Hạn chế từ 24 giờ trở lên: tắt live và KHÔNG bật lại. Chỉ đăng xuất (giữ layout) nếu bật tuỳ chọn severe_logout."""
        logout = bool(self.cfg.get("severe_logout", False))
        if reason:
            what = reason
        elif seconds:
            what = f"LIVE bị hạn chế {fmt_duration(seconds)}"
        else:
            what = "LIVE bị hạn chế từ 24 giờ trở lên"
        self.notify(f"🚫 {what}. Đang tắt live" + (" và đăng xuất tài khoản." if logout else ", sẽ KHÔNG bật lại."))
        self.state = "ending"
        res = self.end_live()
        if res == "already_off":
            self.notify("ℹ️ Live đã tắt sẵn.")
        elif res != "ended":
            self.notify("❌ Không tắt được live (không thấy nút/hộp thoại). Hãy kiểm tra thủ công.")
        else:
            self.notify("⏹ Đã tắt live (không tự bật lại).")
            self._live_seen_at = 0.0
        if not logout:
            self.suppress_until = time.time() + (60 if res in ("ended", "already_off") else 120)
            self.state = "monitoring"
            return
        self.state = "logging_out"
        out = self.logout()
        self.notify({"ok": "🚪 Đã đăng xuất tài khoản (giữ nguyên layout).",
                     "unverified": "⚠️ Đã bấm Log out nhưng không xác nhận được kết quả. Hãy kiểm tra máy.",
                     "fail": "❌ Không đăng xuất được (không mở được menu tài khoản). Hãy đăng xuất thủ công."}[out])
        self.suppress_until = time.time() + (60 if out == "ok" else 300)
        self.state = "monitoring"

    def _sleep_probe(self, total):
        """Chờ tới nhịp kiểm tra kế tiếp, nhưng cứ mỗi fast_probe_seconds lại nhìn nhanh (không OCR); thấy hộp thoại nút hồng thì dừng chờ
        để đọc chữ ngay. True = bị dừng (nút Dừng theo dõi)."""
        step = float(self.cfg.get("fast_probe_seconds", 0) or 0)
        end = time.monotonic() + total
        while True:
            left = end - time.monotonic()
            if left <= 0:
                return False
            if self.stop.wait(min(step, left) if step > 0 else left):
                return True
            if step > 0 and time.monotonic() >= self._probe_block_until and not self.dry and self.fast_probe():
                self._probe_block_until = time.monotonic() + 20
                return False

    def monitor_loop(self):
        log.info("Bắt đầu theo dõi, kiểm tra mỗi %ss%s", self.cfg["check_interval_seconds"],
                 " [dry-run]" if self.dry else "")
        while not self.stop.is_set():
            t0 = time.monotonic()
            try:
                self.check_once()
            except Exception as e:
                log.exception("Lỗi chu kỳ kiểm tra")
                self.state = "monitoring"
                if type(e).__name__ == "FailSafeException":
                    log.info("🛑 Failsafe (chuột ở góc màn hình): đã dừng theo dõi.")
                    self.shutdown()
                    return
                self.suppress_until = time.time() + 60
                if time.time() - self._last_err > 600:
                    self._last_err = time.time()
                    log.error("❌ Lỗi: %s", e)
            if self._sleep_probe(max(1.0, self.cfg["check_interval_seconds"] - (time.monotonic() - t0))):
                return

    def simulate(self, kind="short"):
        """Chạy thử 1 vòng cảnh báo ('short', 'severe' hoặc 'notice' = thông báo bất kỳ). Dùng với dry=True: không click, chờ tối đa 5 giây."""
        try:
            if kind == "notice":
                self.handle_warning("short", None, None, reason="Chạy thử: có thông báo của TikTok che màn hình live")
            else:
                self.handle_warning(kind, None, 600 if kind == "short" else 7 * 86400)
        except Exception as e:
            log.exception("Lỗi khi chạy thử")
            self.notify(f"❌ Lỗi khi chạy thử: {e}")
        finally:
            self.state = "monitoring"
            if self.after_simulate:
                self.after_simulate()

    def start(self, simulate=None):
        self.stop = threading.Event()
        self.running = True
        target = (lambda: self.simulate(simulate)) if simulate else self.monitor_loop
        threading.Thread(target=target, daemon=True).start()

    def shutdown(self):
        self.stop.set()
        self.running = False


# --------------------------------------------------------------------------- lệnh phụ
def calibrate_report(cfg):
    """Chụp + OCR 1 lần. Trả về (danh sách dòng mô tả, đường dẫn ảnh debug)."""
    g = Guard(cfg, dry=True)
    snap = g.snap()
    img, l, t, items = snap

    def fmt(pt):
        return f"thấy tại ({pt[0]:.0f}, {pt[1]:.0f})" if pt else "KHÔNG thấy"

    sev = "NẶNG (tắt live, KHÔNG bật lại" + (", đăng xuất)" if cfg.get("severe_logout") else ")")
    det = g.analyze(items)
    if det is None:
        warn = "không có"
    else:
        warn = ("CÓ - " + sev if det.kind == "severe" else "CÓ - ngắn (tắt live rồi bật lại)") + \
               f", thời hạn đọc được: {fmt_duration(det.seconds)}, bằng chứng: {g.evidence(snap) or 'KHÔNG CÓ (sẽ bị bỏ qua)'}"
    out = ["Cửa sổ TikTok LIVE Studio: " + ("thấy" if g.studio_window() else "KHÔNG thấy (đang đọc toàn màn hình)"),
           "", "Chữ đọc được trên màn hình:"]
    out += [f"  ({it.cx + l:.0f},{it.cy + t:.0f})  {it.text}" for it in items] or ["  (không đọc được chữ nào)"]
    n = g.find_notice(snap)
    if n is None:
        notice = "không có"
    else:
        kind, secs = g.notice_severity(n.text)
        notice = (f"CÓ - nút: {', '.join(b['label'] + (' (hồng)' if b['pink'] else '') for b in n.buttons)}; "
                  f"{sev.lower() if kind == 'severe' else 'sẽ đóng thông báo, tắt live rồi bật lại'}; chữ: {n.text[:120]}")
    out += ["", f"Cảnh báo hạn chế LIVE: {warn}", f"Nút OK của cảnh báo: {fmt(g.find_ok(snap))}",
            f"Hộp thông báo bất kỳ che màn hình live: {notice}"]
    out.append(f"Đồng hồ đếm giờ live (bấm vào đây để mở menu End LIVE): {fmt(g.find_timer(snap))}")
    for kind, name in (("end_live", "Mục End LIVE (chỉ thấy khi menu đã mở)"), ("confirm_end", "Nút xác nhận kết thúc"), ("go_live", "Nút Go LIVE"),
                       ("logout", "Mục Log out trong menu")):
        out.append(f"{name}: {fmt(g.locate(kind, snap))}")
    cands = g.find_account(snap)
    out.append("Ảnh đại diện (bấm để mở menu tài khoản): " + "; ".join(f"({x:.0f}, {y:.0f}) {how}" for x, y, how in cands))
    dlg = g.logout_dialog(snap)
    if dlg:
        keep, cancel = dlg
        out.append(f"Hộp thoại Log out: CÓ, ô tick 'Keep the layout': {g.checkbox_state(img, keep)}, "
                   f"nút Log out: {fmt(g.logout_button(snap, keep, cancel))}")
    else:
        out.append("Hộp thoại Log out: không có")
    return out, g.save_debug(snap, "debug_last.png")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config")
    ap.add_argument("--calibrate", action="store_true")
    ap.add_argument("--simulate", choices=["short", "severe", "notice"])
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--version", action="store_true")
    args = ap.parse_args()
    if args.version:
        return print(__version__)
    setup_logging()
    cfg = load_config(args.config)
    if args.calibrate:
        lines, path = calibrate_report(cfg)
        print("\n".join(lines))
        return print(f"\nĐã lưu {path}")
    guard = Guard(cfg, dry=args.dry_run)
    done = threading.Event()
    guard.after_simulate = done.set
    guard.start(simulate=args.simulate)
    try:
        while not done.wait(0.5) and guard.running:
            pass
    except KeyboardInterrupt:
        pass
    guard.shutdown()


if __name__ == "__main__":
    main()
