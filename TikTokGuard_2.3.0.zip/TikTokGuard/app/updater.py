#!/usr/bin/env python3
"""TikTok Guard - cập nhật nóng (chỉ dùng thư viện chuẩn của Python).

Luồng: lấy latest.json -> thấy bản mới -> tải gói zip (kiểm sha256) -> giải nén ra thư mục tạm -> kiểm tra (biên dịch được,
tự chạy thử bản mới) -> khi phần mềm đang rảnh: sao lưu bản cũ, ghi đè file, khởi động lại. Bản mới không lên được trong
~45 giây thì tự khôi phục bản cũ.

latest.json (đặt ở bất kỳ chỗ nào tải được bằng https):
    {"version": "2.1.2", "url": "TikTokGuard_2.1.2.zip", "sha256": "<sha256 của file zip>", "notes": "Sửa ..."}
"url" có thể là đường dẫn tương đối (tính từ chỗ đặt latest.json). Gói zip chính là file TikTokGuard_x.y.z.zip dùng để cài mới.
"""
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

log = logging.getLogger("guard")

ALLOWED = re.compile(r"^(?:[A-Za-z0-9_]+\.py|requirements\.txt|icon\.ico)$")   # chỉ cho cập nhật các file này, phẳng, không thư mục con
MAX_JSON = 64 * 1024
MAX_ZIP = 60 * 1024 * 1024
MAX_UNPACKED = 30 * 1024 * 1024
READY_FLAG = "update_ready.flag"
STATE_FILE = "update_state.json"
LOOPBACK = ("127.0.0.1", "localhost", "::1")


class UpdateError(Exception):
    pass


# ---------------------------------------------------------------- phiên bản
def parse_version(v):
    nums = re.findall(r"\d+", str(v))[:4]
    if not nums:
        raise UpdateError(f"Số phiên bản không hợp lệ: {v!r}")
    return tuple(int(n) for n in nums) + (0,) * (4 - len(nums))


def is_newer(a, b):
    return parse_version(a) > parse_version(b)


# ---------------------------------------------------------------- trạng thái (bản đã từng lỗi, lần kiểm tra cuối)
def _state(data_dir):
    try:
        return json.loads((Path(data_dir) / STATE_FILE).read_text("utf-8"))
    except Exception:
        return {}


def _save_state(data_dir, st):
    try:
        (Path(data_dir) / STATE_FILE).write_text(json.dumps(st, ensure_ascii=False, indent=1), "utf-8")
    except Exception:
        pass


def mark_bad(data_dir, version):
    st = _state(data_dir)
    st.setdefault("bad", {})[str(version)] = time.time()
    _save_state(data_dir, st)


def is_bad(data_dir, version):
    return str(version) in _state(data_dir).get("bad", {})


# ---------------------------------------------------------------- tải về
def _check_url(url):
    u = urllib.parse.urlparse(url)
    if u.scheme == "https" and u.netloc:
        return url
    if u.scheme == "http" and (u.hostname or "") in LOOPBACK:
        return url                                  # chỉ cho http với máy local (dùng để thử)
    raise UpdateError("Link cập nhật phải bắt đầu bằng https://")


def _open(url, timeout):
    req = urllib.request.Request(_check_url(url), headers={"User-Agent": "TikTokGuard-updater", "Cache-Control": "no-cache"})
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except Exception as e:
        raise UpdateError(f"Không tải được {url}: {e}")


def fetch_manifest(url, timeout=20):
    """Đọc latest.json -> {version, url (tuyệt đối), sha256 hoặc None, notes}."""
    with _open(url, timeout) as r:
        raw = r.read(MAX_JSON + 1)
    if len(raw) > MAX_JSON:
        raise UpdateError("latest.json quá lớn, có vẻ sai link")
    try:
        m = json.loads(raw.decode("utf-8-sig"))
        version = str(m["version"]).strip()
    except Exception:
        raise UpdateError("latest.json không đúng định dạng (cần có \"version\")")
    parse_version(version)
    zurl = urllib.parse.urljoin(url, str(m.get("url") or f"TikTokGuard_{version}.zip"))
    _check_url(zurl)
    sha = (str(m.get("sha256") or "")).strip().lower() or None
    if sha and not re.fullmatch(r"[0-9a-f]{64}", sha):
        raise UpdateError("sha256 trong latest.json không hợp lệ")
    return {"version": version, "url": zurl, "sha256": sha, "notes": str(m.get("notes") or "")}


def download(url, dest, sha256=None, timeout=120):
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    h, size = hashlib.sha256(), 0
    try:
        with _open(url, timeout) as r, open(part, "wb") as f:
            while True:
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_ZIP:
                    raise UpdateError("File cập nhật quá lớn")
                h.update(chunk)
                f.write(chunk)
        if sha256 and h.hexdigest() != sha256.lower():
            raise UpdateError("File cập nhật tải về bị sai/hỏng (sha256 không khớp), không cài")
        part.replace(dest)
    finally:
        part.unlink(missing_ok=True)
    return dest


# ---------------------------------------------------------------- mở gói + kiểm tra
def find_python_exe():
    exe = Path(sys.executable)
    if exe.name.lower().startswith("pythonw"):
        cand = exe.with_name("python.exe")
        if cand.exists():
            return str(cand)
    return str(exe)


def _run(cmd, cwd, timeout, env=None):
    kw = {}
    if sys.platform == "win32":
        kw["creationflags"] = 0x08000000          # CREATE_NO_WINDOW
    try:
        return subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, timeout=timeout, env=env, **kw)
    except subprocess.TimeoutExpired:
        raise UpdateError(f"Chạy thử bản mới bị treo ({' '.join(map(str, cmd[1:3]))})")


def stage_package(zip_path, staging_dir, python_exe=None, selftest=True):
    """Giải nén gói (zip cài đặt đầy đủ hoặc zip chỉ có file chương trình) vào staging_dir và kiểm tra. Trả {version, files, dir}."""
    zip_path, staging = Path(zip_path), Path(staging_dir)
    try:
        z = zipfile.ZipFile(zip_path)
    except Exception:
        raise UpdateError("Không phải file zip hợp lệ")
    with z:
        infos = {i.filename.replace("\\", "/"): i for i in z.infolist() if not i.is_dir()}
        for n in infos:
            if n.startswith("/") or ".." in n.split("/") or re.match(r"^[A-Za-z]:", n):
                raise UpdateError(f"Gói chứa đường dẫn không an toàn: {n}")
        prefixes = sorted({n[:-len("app.py")] for n in infos if n.endswith("app.py") and n[:-len("app.py")] + "guard.py" in infos
                           and (n == "app.py" or n.endswith("/app.py"))}, key=len)
        if not prefixes:
            raise UpdateError("Gói không có app.py và guard.py (không phải bản TikTok Guard)")
        pre = prefixes[0]
        picked = {}
        for n, i in infos.items():
            if n.startswith(pre) and "/" not in n[len(pre):] and ALLOWED.match(n[len(pre):]):
                picked[n[len(pre):]] = i
        if sum(i.file_size for i in picked.values()) > MAX_UNPACKED:
            raise UpdateError("Gói giải nén ra quá lớn")
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        staging.mkdir(parents=True, exist_ok=True)
        for name, i in picked.items():
            (staging / name).write_bytes(z.read(i))
    m = re.search(r'^__version__\s*=\s*"([^"]+)"', (staging / "guard.py").read_text("utf-8"), re.M)
    if not m:
        raise UpdateError("guard.py trong gói không ghi số phiên bản")
    version = m.group(1)
    for f in sorted(staging.glob("*.py")):
        try:
            compile(f.read_text("utf-8"), str(f), "exec")
        except SyntaxError as e:
            raise UpdateError(f"{f.name} có lỗi cú pháp (dòng {e.lineno}), không cài")
    if selftest:
        py = python_exe or find_python_exe()
        home = tempfile.mkdtemp(prefix="tg_selftest_")
        env = dict(os.environ, TIKTOK_GUARD_HOME=home)
        try:
            r = _run([py, "guard.py", "--version"], staging, 40, env)
            if r.returncode != 0 or r.stdout.strip() != version:
                raise UpdateError("Bản mới không chạy được (guard.py --version): " + (r.stderr or r.stdout).strip()[-300:])
            r = _run([py, "app.py", "--selftest"], staging, 60, env)
            if r.returncode != 0 or "SELFTEST OK" not in r.stdout:
                raise UpdateError("Bản mới không dựng được giao diện: " + (r.stderr or r.stdout).strip()[-300:])
        finally:
            shutil.rmtree(home, ignore_errors=True)
    return {"version": version, "files": sorted(picked), "dir": str(staging)}


def fetch_and_stage(url, current, data_dir, python_exe=None, skip_bad=True, timeout=30):
    """Kiểm tra link cập nhật. Không có bản mới -> None. Có -> đã tải + kiểm tra xong, trả info (xem stage_package) + notes."""
    m = fetch_manifest(url, timeout)
    if not is_newer(m["version"], current):
        return None
    if skip_bad and is_bad(data_dir, m["version"]):
        log.info("Bản %s từng cài lỗi trên máy này nên bỏ qua (có thể cập nhật thủ công).", m["version"])
        return None
    data_dir = Path(data_dir)
    zp = download(m["url"], data_dir / "update_download.zip", m["sha256"])
    try:
        info = stage_package(zp, data_dir / "update_staging", python_exe)
    finally:
        zp.unlink(missing_ok=True)
    if info["version"] != m["version"]:
        raise UpdateError(f"Gói chứa bản {info['version']} nhưng latest.json nói {m['version']}, không cài")
    info["notes"] = m["notes"]
    return info


def stage_from_file(zip_path, data_dir, python_exe=None):
    info = stage_package(zip_path, Path(data_dir) / "update_staging", python_exe)
    info["notes"] = ""
    return info


# ---------------------------------------------------------------- áp dụng / khôi phục
def requirements_changed(staging_dir, app_dir):
    def norm(p):
        try:
            return {ln.strip().lower() for ln in Path(p).read_text("utf-8").splitlines() if ln.strip() and not ln.strip().startswith("#")}
        except Exception:
            return set()
    new = Path(staging_dir) / "requirements.txt"
    return new.exists() and norm(new) != norm(Path(app_dir) / "requirements.txt")


def install_requirements(python_exe, req_path, timeout=900):
    """pip install thư viện mới; lỗi chứng chỉ (máy thuê) thì thử lại bằng kho chứng chỉ Windows rồi --trusted-host (giống install.bat)."""
    base = [python_exe, "-m", "pip", "install", "-r", str(req_path), "--disable-pip-version-check"]
    tries = [[], ["--use-feature=truststore"],
             ["--trusted-host", "pypi.org", "--trusted-host", "files.pythonhosted.org", "--trusted-host", "pypi.python.org"]]
    last = ""
    for extra in tries:
        try:
            r = _run(base + extra, Path(req_path).parent, timeout)
        except UpdateError as e:
            last = str(e)
            continue
        if r.returncode == 0:
            return
        last = (r.stderr or r.stdout).strip()[-300:]
    raise UpdateError("Cài thư viện mới thất bại: " + last)


def apply_staged(staging_dir, files, app_dir, backup_dir, old_version=""):
    staging, app, backup = Path(staging_dir), Path(app_dir), Path(backup_dir)
    if backup.exists():
        shutil.rmtree(backup, ignore_errors=True)
    backup.mkdir(parents=True)
    existed = [f for f in files if (app / f).exists()]
    for f in existed:
        shutil.copy2(app / f, backup / f)
    (backup / "_backup.json").write_text(json.dumps({"version": old_version, "files": existed, "new": [f for f in files if f not in existed]}), "utf-8")
    try:
        for f in files:
            tmp = app / (f + ".new")
            shutil.copy2(staging / f, tmp)
            os.replace(tmp, app / f)
    except Exception as e:
        rollback(backup, app)
        raise UpdateError(f"Ghi file cập nhật lỗi ({e}); đã khôi phục bản cũ")


def rollback(backup_dir, app_dir):
    backup, app = Path(backup_dir), Path(app_dir)
    try:
        meta = json.loads((backup / "_backup.json").read_text("utf-8"))
    except Exception:
        return False
    for f in meta.get("files", []):
        shutil.copy2(backup / f, app / f)
    for f in meta.get("new", []):
        (app / f).unlink(missing_ok=True)
    for f in app.glob("*.new"):
        f.unlink(missing_ok=True)
    return True


def swap_and_restart(info, app_dir, backup_dir, data_dir, spawn_cmd, release, reacquire, old_version="",
                     popen=subprocess.Popen, sleep=time.sleep, now=time.time, wait=45):
    """Ghi đè file -> nhả khoá 1-bản -> mở tiến trình mới -> chờ nó báo sẵn sàng.
    Trả 'ok' (tiến trình gọi hàm này nên thoát ngay) hoặc 'rolled_back' (bản mới không lên được, đã khôi phục file cũ,
    tiến trình này tiếp tục chạy bản cũ)."""
    flag = Path(data_dir) / READY_FLAG
    flag.unlink(missing_ok=True)
    apply_staged(info["dir"], info["files"], app_dir, backup_dir, old_version)
    release()
    kw = {"start_new_session": True} if sys.platform != "win32" else {"creationflags": 0x00000008 | 0x00000200}   # DETACHED | NEW_PROCESS_GROUP
    try:
        proc = popen(spawn_cmd, cwd=str(app_dir), close_fds=True, **kw)
    except Exception as e:
        rollback(backup_dir, app_dir)
        reacquire()
        mark_bad(data_dir, info["version"])
        raise UpdateError(f"Không mở được bản mới ({e}); đã khôi phục bản cũ")
    deadline = now() + wait
    while now() < deadline:
        try:
            if flag.exists() and flag.read_text("utf-8").strip() == info["version"]:
                return "ok"
        except OSError:
            pass
        if proc.poll() is not None and not flag.exists():
            break                                     # tiến trình mới đã chết
        sleep(0.5)
    if flag.exists() and flag.read_text("utf-8").strip() == info["version"]:
        return "ok"
    try:
        proc.kill()
    except Exception:
        pass
    sleep(1.0)
    rollback(backup_dir, app_dir)
    mark_bad(data_dir, info["version"])
    reacquire()
    return "rolled_back"
