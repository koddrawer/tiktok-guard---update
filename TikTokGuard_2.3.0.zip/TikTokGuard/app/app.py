#!/usr/bin/env python3
"""TikTok Guard 2.1 - giao diện tối giản (Windows). Một cửa sổ: trạng thái, Bắt đầu/Dừng, thời gian bật lại live, cập nhật nóng, nhật ký."""
import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import guard as G
import updater as U

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
FONT = ("Segoe UI", 10)
MONO = ("Consolas", 9)
GREEN, GREY, ORANGE = "#1a9c4b", "#777777", "#d9822b"


# ---------------------------------------------------------------- khởi động cùng Windows
def _autostart_command():
    if getattr(sys, "frozen", False):
        return f'"{sys.executable}" --minimized'
    exe = Path(sys.executable)
    pw = exe.with_name("pythonw.exe")
    return f'"{pw if pw.exists() else exe}" "{Path(__file__).resolve()}" --minimized'


def get_autostart():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            winreg.QueryValueEx(k, G.APP_NAME)
            return True
    except Exception:
        return False


def set_autostart(on):
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
            if on:
                winreg.SetValueEx(k, G.APP_NAME, 0, winreg.REG_SZ, _autostart_command())
            else:
                try:
                    winreg.DeleteValue(k, G.APP_NAME)
                except FileNotFoundError:
                    pass
        return True
    except Exception as e:
        G.log.warning("Không đổi được chế độ khởi động cùng Windows: %s", e)
        return False


def open_path(p):
    try:
        if hasattr(os, "startfile"):
            os.startfile(str(p))
        else:
            subprocess.Popen(["xdg-open", str(p)])
    except Exception as e:
        messagebox.showerror("TikTok Guard", f"Không mở được: {p}\n{e}")


class UiHandler(G.logging.Handler):
    def __init__(self, q):
        super().__init__()
        self.q = q

    def emit(self, record):
        line = f"{time.strftime('%H:%M:%S')}  {record.getMessage()}"
        if record.exc_info:
            line += f"  ({record.exc_info[0].__name__}: {record.exc_info[1]})"
        self.q.put(line)


def app_dir():
    return Path(__file__).resolve().parent


def restart_command(minimized, paused):
    """Lệnh mở lại phần mềm sau khi cập nhật (cùng kiểu với lệnh khởi động cùng Windows)."""
    exe = Path(sys.executable)
    pw = exe.with_name("pythonw.exe")
    cmd = [str(pw if pw.exists() else exe), str(Path(__file__).resolve()), "--after-update"]
    return cmd + (["--minimized"] if minimized else []) + (["--paused"] if paused else [])


class App:
    def __init__(self, selftest=False):
        self.root = tk.Tk()
        self.root.title(f"TikTok Guard {G.__version__}")
        self.root.geometry("680x800")
        self.root.minsize(560, 600)
        try:
            self.root.iconbitmap(str(G.BASE / "icon.ico"))
        except Exception:
            pass
        self.root.option_add("*Font", FONT)
        style = ttk.Style()
        style.theme_use("vista" if "vista" in style.theme_names() else "clam")
        style.configure("Big.TLabel", font=("Segoe UI", 16, "bold"))
        style.configure("Hint.TLabel", foreground="#666666")
        self.root.report_callback_exception = \
            lambda exc, val, tb: G.log.error("Lỗi giao diện: %s: %s", exc.__name__, val)

        self.log_q, self.ui_q = queue.Queue(), queue.Queue()
        G.setup_logging(UiHandler(self.log_q))
        self.cfg = G.load_config()
        self.guard = None
        self.pending = None                 # bản cập nhật đã tải + kiểm tra xong, chờ lúc rảnh để cài
        self.update_busy = False
        self.next_check = time.time() + 30
        self.ticks, self.ready_written = 0, False
        self.after_update = "--after-update" in sys.argv
        self._build()
        if selftest:                        # app.py --selftest: dùng để kiểm tra gói cập nhật trước khi cài
            self.refresh_status()
            self.root.update()
            self.root.destroy()
            print("SELFTEST OK", G.__version__)
            return
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        if "--minimized" in sys.argv:
            self.root.iconify()
        G.log.info("TikTok Guard %s · dữ liệu lưu tại %s", G.__version__, G.DATA)
        if self.after_update:
            shutil_rmtree(G.DATA / "update_staging")
        if self.cfg.get("auto_start_monitoring", True) and "--paused" not in sys.argv:
            self.start()
        self.root.after(300, self.tick)

    # ------------------------------------------------------------ giao diện
    def _build(self):
        r = self.root
        top = ttk.Frame(r)
        top.pack(fill="x", padx=14, pady=(12, 4))
        self.status_lbl = ttk.Label(top, text="", style="Big.TLabel")
        self.status_lbl.pack(anchor="w")
        self.sub_lbl = ttk.Label(top, text="", style="Hint.TLabel")
        self.sub_lbl.pack(anchor="w", pady=(2, 0))

        rules = ttk.LabelFrame(r, text="Phần mềm làm gì")
        rules.pack(fill="x", padx=14, pady=(6, 2))
        ttk.Label(rules, justify="left", text=(
            "•  Thấy thông báo hạn chế LIVE, hoặc BẤT KỲ thông báo nào của TikTok che\n"
            "    màn hình live  →  tắt thông báo, ngừng live ngay, vài phút sau bật lại.\n"
            "•  Hạn chế từ 24 giờ trở lên (7 ngày...)  →  tắt thông báo, ngừng live,\n"
            "    KHÔNG bật lại (đăng xuất nếu bạn tick ô \"Đăng xuất\" ở Cài đặt).")) \
            .pack(anchor="w", padx=10, pady=6)

        row = ttk.Frame(r)
        row.pack(fill="x", padx=14, pady=8)
        self.btn_start = ttk.Button(row, text="▶  Bắt đầu theo dõi", command=self.start)
        self.btn_start.pack(side="left")
        self.btn_stop = ttk.Button(row, text="■  Dừng theo dõi", command=self.stop)
        self.btn_stop.pack(side="left", padx=8)

        st = ttk.LabelFrame(r, text="Cài đặt")
        st.pack(fill="x", padx=14, pady=(0, 6))
        line = ttk.Frame(st)
        line.pack(fill="x", padx=10, pady=(8, 2))
        ttk.Label(line, text="Tắt live rồi bật lại sau").pack(side="left")
        self.delay_var = tk.StringVar(value=str(max(1, round(self.cfg["restart_delay_seconds"] / 60))))
        ttk.Entry(line, textvariable=self.delay_var, width=5, justify="center").pack(side="left", padx=6)
        ttk.Label(line, text="phút").pack(side="left")
        self.notice_var = tk.BooleanVar(value=bool(self.cfg.get("notice_enabled", True)))
        ttk.Checkbutton(st, text="Thông báo/hộp thoại bất kỳ của TikTok che màn hình live cũng tắt live rồi bật lại", variable=self.notice_var) \
            .pack(anchor="w", padx=10, pady=2)
        self.logout_var = tk.BooleanVar(value=bool(self.cfg.get("severe_logout", False)))
        ttk.Checkbutton(st, text="Hạn chế từ 24 giờ trở lên: đăng xuất tài khoản (không tick = chỉ tắt live, không bật lại)", variable=self.logout_var) \
            .pack(anchor="w", padx=10, pady=2)
        self.autostart_var = tk.BooleanVar(value=get_autostart())
        ttk.Checkbutton(st, text="Tự mở và theo dõi khi bật máy (khởi động cùng Windows)", variable=self.autostart_var) \
            .pack(anchor="w", padx=10, pady=2)
        foot = ttk.Frame(st)
        foot.pack(fill="x", padx=10, pady=(2, 8))
        ttk.Button(foot, text="Lưu", command=self.save).pack(side="left")
        self.save_lbl = ttk.Label(foot, text="", style="Hint.TLabel")
        self.save_lbl.pack(side="left", padx=10)

        up = ttk.LabelFrame(r, text="Cập nhật")
        up.pack(fill="x", padx=14, pady=(0, 6))
        l1 = ttk.Frame(up)
        l1.pack(fill="x", padx=10, pady=(8, 2))
        ttk.Label(l1, text=f"Phiên bản {G.__version__}").pack(side="left")
        self.update_lbl = ttk.Label(l1, text="", style="Hint.TLabel")
        self.update_lbl.pack(side="left", padx=10)
        l2 = ttk.Frame(up)
        l2.pack(fill="x", padx=10, pady=2)
        ttk.Label(l2, text="Link cập nhật (latest.json):").pack(side="left")
        self.url_var = tk.StringVar(value=self.cfg.get("update_url", ""))
        ttk.Entry(l2, textvariable=self.url_var).pack(side="left", fill="x", expand=True, padx=6)
        self.auto_update_var = tk.BooleanVar(value=bool(self.cfg.get("auto_update", True)))
        ttk.Checkbutton(up, text="Có bản mới thì tự cập nhật khi rảnh (không đang xử lý cảnh báo)", variable=self.auto_update_var) \
            .pack(anchor="w", padx=10, pady=2)
        l3 = ttk.Frame(up)
        l3.pack(fill="x", padx=10, pady=(2, 8))
        self.btn_check = ttk.Button(l3, text="Kiểm tra cập nhật", command=lambda: self.update_check(manual=True))
        self.btn_check.pack(side="left")
        self.btn_file = ttk.Button(l3, text="Cập nhật từ file…", command=self.update_from_file)
        self.btn_file.pack(side="left", padx=8)

        bot = ttk.Frame(r)                       # đáy cửa sổ: luôn hiện, khung nhật ký co lại khi cửa sổ thấp
        bot.pack(side="bottom", fill="x", padx=14, pady=(0, 10))
        ttk.Button(bot, text="Mở thư mục nhật ký / dữ liệu", command=lambda: open_path(G.DATA)).pack(side="left")

        logf = ttk.LabelFrame(r, text="Nhật ký")
        logf.pack(fill="both", expand=True, padx=14, pady=(0, 6))
        self.log_txt = tk.Text(logf, wrap="word", state="disabled", font=MONO, bg="#14141a", fg="#d8d8d8",
                               relief="flat", height=8)
        sb = ttk.Scrollbar(logf, command=self.log_txt.yview)
        self.log_txt.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log_txt.pack(fill="both", expand=True, padx=(4, 0), pady=4)
        self.log_txt.tag_config("bad", foreground="#ff7a8a")
        self.log_txt.tag_config("good", foreground="#6fd98f")
        self.log_txt.tag_config("warn", foreground="#ffb454")


    # ------------------------------------------------------------ điều khiển
    def start(self):
        if self.guard is not None and self.guard.running:
            return
        self.cfg = G.load_config()
        self.guard = G.Guard(self.cfg)
        self.guard.start()
        G.log.info("Đã bắt đầu theo dõi.")

    def stop(self):
        if self.guard is not None and self.guard.running:
            self.guard.shutdown()
            G.log.info("Đã dừng theo dõi.")

    def save(self):
        try:
            minutes = int(self.delay_var.get().strip())
            if not 1 <= minutes <= 1440:
                raise ValueError
        except ValueError:
            return messagebox.showerror("Giá trị không hợp lệ", "Số phút bật lại live phải là số nguyên từ 1 đến 1440.")
        url = self.url_var.get().strip()
        if url:
            try:
                U._check_url(url)
            except U.UpdateError as e:
                return messagebox.showerror("Link cập nhật", str(e))
        cfg = G.load_config()
        cfg["restart_delay_seconds"] = minutes * 60
        cfg["notice_enabled"] = bool(self.notice_var.get())
        cfg["severe_logout"] = bool(self.logout_var.get())
        cfg["update_url"] = url
        cfg["auto_update"] = bool(self.auto_update_var.get())
        G.save_config(cfg)
        self.cfg = cfg
        set_autostart(self.autostart_var.get())
        g = self.guard
        if g is not None and g.running:
            g.cfg["restart_delay_seconds"] = minutes * 60     # áp dụng ngay, không khởi động lại (không huỷ việc bật lại live đang chờ)
            g.cfg["notice_enabled"] = bool(self.notice_var.get())
            g.cfg["severe_logout"] = bool(self.logout_var.get())
        self.next_check = min(self.next_check, time.time() + 5)
        self.save_lbl.config(text=f"✓ Đã lưu lúc {time.strftime('%H:%M:%S')}")

    # ------------------------------------------------------------ cập nhật nóng
    def set_update_text(self, text):
        self.update_lbl.config(text=text)

    def idle(self):
        g = self.guard
        return g is None or not g.running or g.state == "monitoring"

    def update_check(self, manual=False):
        if getattr(sys, "frozen", False):
            if manual:
                messagebox.showinfo("Cập nhật", "Bản .exe đóng gói sẵn không cập nhật nóng được. Hãy cài lại bằng install.bat.")
            return
        if self.update_busy or self.pending and self.pending.get("applying"):
            return
        url = (self.url_var.get() if manual else self.cfg.get("update_url", "")).strip()
        if not url:
            if manual:
                messagebox.showinfo("Cập nhật", "Chưa có link cập nhật. Dán link latest.json vào ô rồi bấm Lưu.\n"
                                                "Hoặc bấm \"Cập nhật từ file…\" để chọn file TikTokGuard_x.y.z.zip.")
            return
        self.update_busy = True
        self.set_update_text("Đang kiểm tra cập nhật…")

        def work():
            try:
                info = U.fetch_and_stage(url, G.__version__, G.DATA, skip_bad=not manual)
                self.ui_q.put(lambda: self.on_update_result(info, manual, None))
            except Exception as e:
                self.ui_q.put(lambda err=e: self.on_update_result(None, manual, err))
        threading.Thread(target=work, daemon=True).start()

    def update_from_file(self):
        if getattr(sys, "frozen", False):
            return messagebox.showinfo("Cập nhật", "Bản .exe đóng gói sẵn không cập nhật nóng được. Hãy cài lại bằng install.bat.")
        if self.update_busy or self.pending and self.pending.get("applying"):
            return
        path = filedialog.askopenfilename(title="Chọn file cập nhật (TikTokGuard_x.y.z.zip)", filetypes=[("Gói TikTok Guard", "*.zip")])
        if not path:
            return
        self.update_busy = True
        self.set_update_text("Đang kiểm tra file…")

        def work():
            try:
                info = U.stage_from_file(path, G.DATA)
                self.ui_q.put(lambda: self.on_update_result(info, True, None, from_file=True))
            except Exception as e:
                self.ui_q.put(lambda err=e: self.on_update_result(None, True, err))
        threading.Thread(target=work, daemon=True).start()

    def on_update_result(self, info, manual, err, from_file=False):
        self.update_busy = False
        hours = max(1, int(self.cfg.get("update_check_hours", 6)))
        self.next_check = time.time() + hours * 3600
        now = time.strftime("%H:%M")
        if err is not None:
            msg = str(err) if isinstance(err, U.UpdateError) else f"{type(err).__name__}: {err}"
            G.log.warning("Cập nhật: %s", msg)
            self.set_update_text(f"Lỗi cập nhật lúc {now}")
            if manual:
                messagebox.showerror("Cập nhật", msg)
            return
        if info is None:
            self.set_update_text(f"Đang dùng bản mới nhất · kiểm tra lúc {now}")
            if manual:
                messagebox.showinfo("Cập nhật", f"Đang dùng bản mới nhất ({G.__version__}).")
            return
        ver = info["version"]
        notes = f"\n\n{info['notes']}" if info.get("notes") else ""
        if from_file and not U.is_newer(ver, G.__version__):
            if not messagebox.askyesno("Cập nhật từ file", f"Bản trong file ({ver}) không mới hơn bản đang chạy ({G.__version__}).\nVẫn cài đè?"):
                self.set_update_text("Đã hủy")
                return
        elif manual:
            if not messagebox.askyesno("Cập nhật", f"Có bản {ver} (đang dùng {G.__version__}).{notes}\n\n"
                                                    "Cập nhật ngay? Phần mềm tự khởi động lại trong vài giây, live không bị ảnh hưởng."):
                self.pending = None
                self.set_update_text(f"Có bản {ver} (chưa cài)")
                return
        elif not self.cfg.get("auto_update", True):
            self.pending = None
            self.set_update_text(f"Có bản {ver} · bấm \"Kiểm tra cập nhật\" để cài")
            G.log.info("Có bản mới %s (chưa bật tự cập nhật).", ver)
            return
        info["manual"] = manual
        self.pending = info
        if self.idle():
            self.apply_update()
        else:
            self.set_update_text(f"Có bản {ver} · sẽ cài khi xong việc đang làm")
            G.log.info("Có bản mới %s, sẽ cài khi phần mềm rảnh (đang %s).", ver, self.guard.state)

    def apply_update(self):
        info = self.pending
        if not info or info.get("applying") or not self.idle():
            return
        info["applying"] = True
        self.set_update_text(f"Đang cập nhật lên {info['version']}…")
        G.log.info("Đang cập nhật lên %s…", info["version"])
        g = self.guard
        was_running = bool(g is not None and g.running)

        def work():
            stopped = False
            try:
                py = U.find_python_exe()
                if U.requirements_changed(info["dir"], app_dir()):
                    self.ui_q.put(lambda: self.set_update_text("Đang cài thư viện mới…"))
                    U.install_requirements(py, Path(info["dir"]) / "requirements.txt")
                if was_running:
                    if g.state != "monitoring":
                        raise U.UpdateError("__busy__")
                    g.shutdown()
                    stopped = True
                res = U.swap_and_restart(
                    info, app_dir(), G.DATA / "update_backup", G.DATA,
                    restart_command(minimized=not info.get("manual"), paused=not was_running),
                    release=G.release_single_instance, reacquire=lambda: G.acquire_single_instance(wait=5),
                    old_version=G.__version__)
                if res == "ok":
                    G.log.info("Đã cập nhật lên %s, đang khởi động lại.", info["version"])
                    for h in list(G.log.handlers):
                        try:
                            h.flush()
                        except Exception:
                            pass
                    os._exit(0)
                raise U.UpdateError(f"Bản {info['version']} không khởi động được nên đã giữ lại bản {G.__version__}")
            except Exception as e:
                msg = str(e)
                self.ui_q.put(lambda: self.on_apply_failed(info, msg, stopped and was_running))
        threading.Thread(target=work, daemon=True).start()

    def on_apply_failed(self, info, msg, restart_guard):
        info["applying"] = False
        if msg == "__busy__":
            self.set_update_text(f"Có bản {info['version']} · sẽ cài khi xong việc đang làm")
            return
        self.pending = None
        G.log.error("❌ Cập nhật lỗi: %s", msg)
        self.set_update_text("Cập nhật lỗi, vẫn dùng bản cũ")
        if restart_guard and (self.guard is None or not self.guard.running):
            self.start()
        if info.get("manual"):
            messagebox.showerror("Cập nhật", msg)

    def update_poll(self):
        """Gọi mỗi ~5 giây: cài bản đang chờ khi rảnh; kiểm tra định kỳ khi có link."""
        p = self.pending
        if p and not p.get("applying") and self.idle():
            self.apply_update()
        elif not p and not self.update_busy and self.cfg.get("update_url") and time.time() >= self.next_check:
            self.update_check(manual=False)

    # ------------------------------------------------------------ vòng cập nhật
    def _set_status(self, text, color, sub):
        self.status_lbl.config(text=text, foreground=color)
        self.sub_lbl.config(text=sub)

    def refresh_status(self):
        g = self.guard
        if g is None or not g.running:
            self._set_status("■  Đã dừng", GREY, "Bấm \"Bắt đầu theo dõi\" để chạy.")
            self.btn_start.state(["!disabled"])
            self.btn_stop.state(["disabled"])
            return
        self.btn_start.state(["disabled"])
        self.btn_stop.state(["!disabled"])
        st = g.status()
        s, left = st["state"], st["seconds_left"]
        mmss = f"{left // 60:02d}:{left % 60:02d}"
        if s == "monitoring":
            last = time.strftime("%H:%M:%S", time.localtime(g.last_check)) if g.last_check else "chưa có"
            self._set_status("●  Đang theo dõi", GREEN, f"Kiểm tra mỗi {g.cfg['check_interval_seconds']}s · lần gần nhất {last}")
        elif s == "ending":
            self._set_status("⏹  Đang tắt live…", ORANGE, "Đừng chạm chuột trong lúc phần mềm thao tác.")
        elif s == "waiting_restart":
            self._set_status(f"⏸  Đã tắt live, bật lại sau {mmss}", ORANGE, "Bấm \"Dừng theo dõi\" nếu muốn hủy việc bật lại.")
        elif s == "going_live":
            self._set_status("▶  Đang bật lại live…", ORANGE, "Đừng chạm chuột trong lúc phần mềm thao tác.")
        elif s == "logging_out":
            self._set_status("🚪  Đang đăng xuất…", ORANGE, "Đừng chạm chuột trong lúc phần mềm thao tác.")

    def tick(self):
        self.ticks += 1
        try:
            while True:
                self.ui_q.get_nowait()()
        except queue.Empty:
            pass
        if self.after_update and not self.ready_written and self.ticks >= 4:
            self.ready_written = True                 # báo cho tiến trình cũ biết bản mới đã lên được
            try:
                (G.DATA / U.READY_FLAG).write_text(G.__version__, "utf-8")
                G.log.info("✅ Đã cập nhật lên bản %s.", G.__version__)
                self.set_update_text(f"Vừa cập nhật lên {G.__version__}")
            except Exception as e:
                G.log.warning("Không ghi được cờ sẵn sàng: %s", e)
        if self.ticks % 10 == 0:
            self.update_poll()
        lines = []
        try:
            while True:
                lines.append(self.log_q.get_nowait())
        except queue.Empty:
            pass
        if lines:
            t = self.log_txt
            t.configure(state="normal")
            for ln in lines:
                tag = "bad" if ("❌" in ln or "Lỗi" in ln or "lỗi" in ln) else \
                      "warn" if ("⚠️" in ln or "🛑" in ln or "🚫" in ln) else \
                      "good" if ("▶️" in ln or "🚪" in ln or "Đã bắt đầu" in ln) else ""
                t.insert("end", ln + "\n", tag)
            if int(t.index("end-1c").split(".")[0]) > 1500:
                t.delete("1.0", "400.0")
            t.see("end")
            t.configure(state="disabled")
        self.refresh_status()
        self.root.after(500, self.tick)

    def on_close(self):
        if self.guard is not None and self.guard.running:
            if not messagebox.askyesno("Thoát TikTok Guard",
                                       "TikTok Guard đang theo dõi live.\nThoát sẽ dừng theo dõi. Bạn muốn thoát?"):
                return
            self.guard.shutdown()
        self.root.destroy()

    def run(self):
        self.root.mainloop()


def shutil_rmtree(p):
    import shutil
    shutil.rmtree(p, ignore_errors=True)


def main():
    if "--selftest" in sys.argv:
        App(selftest=True)
        return
    if not G.acquire_single_instance(wait=20 if "--after-update" in sys.argv else 0):
        r = tk.Tk()
        r.withdraw()
        messagebox.showinfo("TikTok Guard", "TikTok Guard đang chạy rồi (xem trên thanh tác vụ).")
        return
    App().run()


if __name__ == "__main__":
    main()
