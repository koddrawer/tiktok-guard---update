@echo off
setlocal EnableExtensions
title Cai dat TikTok Guard 2.1
set "SRC=%~dp0app"
set "APP=%LOCALAPPDATA%\TikTokGuard"
set "VPY=%APP%\venv\Scripts\python.exe"

echo ==============================================
echo   CAI DAT TIKTOK GUARD 2.1
echo ==============================================
echo.

if not exist "%SRC%\app.py" (
  echo Khong thay thu muc "app". Hay giai nen TOAN BO file zip roi chay lai install.bat.
  goto :fail
)

rem --- 1. Tim Python 3.10 - 3.12 (PY = lenh py launcher, hoac PYEXE = duong dan python.exe)
set "PY="
set "PYEXE="
call :findpy

if not defined PY if not defined PYEXE (
  echo May chua co Python 3.10-3.12. Dang cai Python 3.12 bang winget, vui long cho...
  winget install -e --id Python.Python.3.12 --source winget --accept-package-agreements --accept-source-agreements
  call :findpy
)

if not defined PY if not defined PYEXE (
  echo.
  echo winget khong cai duoc. Dang tai Python 3.12 truc tiep tu python.org, vui long cho...
  del "%TEMP%\python312_setup.exe" >nul 2>&1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe' -OutFile '%TEMP%\python312_setup.exe'"
  if exist "%TEMP%\python312_setup.exe" (
    echo Dang cai Python 3.12 cho tai khoan nay, khong can quyen quan tri...
    start "" /wait "%TEMP%\python312_setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0
    del "%TEMP%\python312_setup.exe" >nul 2>&1
  )
  call :findpy
)

if not defined PY if not defined PYEXE (
  echo.
  echo *** Khong tu cai duoc Python. Hay cai thu cong:
  echo   1. Mo https://www.python.org/downloads/release/python-3128/ va tai "Windows installer 64-bit".
  echo   2. Chay file do, TICK "Add python.exe to PATH", bam Install Now.
  echo   3. DONG cua so nay va chay lai install.bat.
  echo Neu van loi chung chi/mang: kiem tra ngay gio cua may thue co dung khong, hoac mang cua may co chan tai file khong.
  goto :fail
)

echo [1/4] Sao chep chuong trinh, thay ban cu neu co...
taskkill /F /IM pythonw.exe /FI "WINDOWTITLE eq TikTok Guard*" >nul 2>&1
if not exist "%APP%" mkdir "%APP%"
if exist "%APP%\app" rmdir /S /Q "%APP%\app"
xcopy "%SRC%\*" "%APP%\app\" /E /I /Y /Q >nul
if errorlevel 1 goto :fail

echo [2/4] Tao moi truong Python...
if not exist "%VPY%" (
  if defined PYEXE (
    "%PYEXE%" -m venv "%APP%\venv"
  ) else (
    %PY% -m venv "%APP%\venv"
  )
  if errorlevel 1 goto :fail
)

echo [3/4] Cai thu vien, can internet, co the mat vai phut...
"%VPY%" -m pip install --upgrade pip --disable-pip-version-check >nul 2>&1
"%VPY%" -m pip install -r "%APP%\app\requirements.txt" --disable-pip-version-check
if not errorlevel 1 goto :pipok
echo.
echo Cai thu vien loi. Thu lai bang kho chung chi cua Windows...
"%VPY%" -m pip install -r "%APP%\app\requirements.txt" --disable-pip-version-check --use-feature=truststore
if not errorlevel 1 goto :pipok
echo.
echo Thu lai lan cuoi voi che do bo qua kiem tra chung chi cua pypi.org...
"%VPY%" -m pip install -r "%APP%\app\requirements.txt" --disable-pip-version-check --trusted-host pypi.org --trusted-host files.pythonhosted.org --trusted-host pypi.python.org
if errorlevel 1 goto :fail
:pipok

echo [4/4] Tao shortcut Desktop va Start Menu...
set "PYW=%APP%\venv\Scripts\pythonw.exe"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0make_shortcut.ps1" -Target "%PYW%" -Script "%APP%\app\app.py" -WorkDir "%APP%\app" -Icon "%APP%\app\icon.ico"
if errorlevel 1 goto :fail

copy /Y "%~dp0kiem_tra_man_hinh.bat" "%APP%\kiem_tra_man_hinh.bat" >nul 2>&1

echo.
echo ==============================================
echo   CAI DAT XONG
echo ==============================================
echo Mo "TikTok Guard" tu Desktop hoac Start Menu.
echo Muon kiem tra phan mem co doc duoc man hinh Live Studio khong: chay kiem_tra_man_hinh.bat
echo.
choice /C YN /M "Mo TikTok Guard ngay bay gio"
if errorlevel 2 goto :done
start "" /D "%APP%\app" "%PYW%" "%APP%\app\app.py"

:done
pause
exit /b 0

:fail
echo.
echo *** Cai dat that bai. Xem thong bao loi o phia tren. ***
pause
exit /b 1

:findpy
if defined PY goto :eof
if defined PYEXE goto :eof
for %%V in (3.12 3.11 3.10) do (
  if not defined PY (
    py -%%V -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PY=py -%%V"
  )
)
if defined PY goto :eof
for %%P in ("%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "%ProgramFiles%\Python312\python.exe" "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" "%ProgramFiles%\Python311\python.exe" "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" "%ProgramFiles%\Python310\python.exe") do (
  if not defined PYEXE if exist %%P set "PYEXE=%%~P"
)
goto :eof
