@echo off
rem Chup man hinh 1 lan, doc chu, bao phan mem co thay cac nut / canh bao khong. KHONG click gi ca.
setlocal EnableExtensions
chcp 65001 >nul
set "APP=%LOCALAPPDATA%\TikTokGuard"
set "PYEXE=%APP%\venv\Scripts\python.exe"
if not exist "%PYEXE%" (
  echo Chua cai TikTok Guard. Hay chay install.bat truoc.
  pause
  exit /b 1
)
echo Hay mo TikTok LIVE Studio (man hinh co nut End LIVE hoac Go LIVE) va de nguyen tren man hinh.
echo Dang chup sau 8 giay...
timeout /t 8 /nobreak >nul
cd /d "%APP%\app"
"%PYEXE%" guard.py --calibrate
echo.
echo Anh da chup (khung do = chu doc duoc) nam trong %APPDATA%\TikTokGuard\debug_last.png
if exist "%APPDATA%\TikTokGuard\debug_last.png" start "" "%APPDATA%\TikTokGuard\debug_last.png"
pause
