﻿TIKTOK GUARD 2.3.0
==================

Chạy nền trên Windows, cứ 10 giây đọc màn hình TikTok LIVE Studio (và cứ 2 giây nhìn nhanh xem có hộp thoại hiện ra không) và chỉ làm đúng 2 việc:

  1. Thấy thông báo hạn chế LIVE (dưới 24 giờ, vd 10 phút), HOẶC BẤT KỲ thông báo / hộp thoại nào của TikTok hiện ra che màn hình live
        -> NGAY: đóng thông báo -> ngừng live -> chờ 10 phút -> bật lại live.
  2. Thấy dấu hiệu hạn chế TỪ 24 GIỜ TRỞ LÊN (7 ngày, 1 tuần, 1 tháng, vĩnh viễn / permanently...)
        -> NGAY: đóng thông báo -> ngừng live -> KHÔNG bật lại. Mặc định không làm gì thêm.
        (Từ 2.3.0 KHÔNG còn tự đăng xuất. Muốn đăng xuất như bản trước: tick ô "Hạn chế từ 24 giờ trở lên: đăng xuất tài khoản"
        ở mục Cài đặt rồi bấm Lưu; khi đó nó bấm ảnh đại diện -> "Log out" -> giữ ô "Keep the layout, scene, and source settings
        on this device" được tick -> bấm "Log out".)

"Ngay": thông báo dạng hộp thoại có nút hồng được nhìn nhanh mỗi 2 giây (không tốn CPU) và đọc chữ ngay khi thấy; các trường hợp khác
(tin "System" trong khung chat) được đọc chữ mỗi 10 giây. Sau khi thấy cảnh báo chỉ chờ thêm 1 giây để chụp xác nhận lần 2 rồi làm ngay.
Đọc chữ (OCR) mất khoảng 2 giây CPU mỗi lần: máy thuê yếu bị nặng thì tăng check_interval_seconds (mặc định 10) trong
%APPDATA%\TikTokGuard\config.json; chỉ số nhìn nhanh là fast_probe_seconds (0 = tắt).

Cách TẮT LIVE (theo giao diện Studio của bạn): thanh công cụ dưới chỉ có biểu tượng, nên phần mềm bấm vào ĐỒNG HỒ đếm giờ live
(góc dưới bên phải, vd 00:09:08) -> hiện menu "End LIVE" / "Pause LIVE" -> bấm "End LIVE" (không bao giờ bấm Pause LIVE)
-> nếu Studio hỏi xác nhận thì bấm xác nhận.
Sau khi tắt live, Studio hiện BẢNG TỔNG KẾT (Duration, "That's a wrap!", Total views, New followers...) che mất nút Go LIVE:
phần mềm tự bấm dấu X của CHÍNH BẢNG đó (cạnh chữ "LIVE Center" của bảng, khoảng giữa-trên của cửa sổ) để đóng bảng,
rồi mới bật lại live (luồng 10 phút) hoặc dừng/đăng xuất (hạn chế từ 24 giờ). Phần mềm KHÔNG BAO GIỜ bấm dấu X đóng cửa sổ
TikTok LIVE Studio ở góc trên cùng bên phải (cạnh nút thu nhỏ/phóng to).

Nhận ra các dạng thông báo hạn chế đã biết: hộp thoại có nút OK/Appeal (tiếng Anh) và tin nhắn "System" trong khung chat (tiếng Việt, không có nút).

THÔNG BÁO BẤT KỲ CHE MÀN HÌNH LIVE (mới từ 2.2.0)
  Ngoài các thông báo hạn chế ở trên, bất kỳ hộp thông báo nào của TikTok hiện ra giữa màn hình Studio đều được xử lý như hạn chế 10 phút:
  đóng thông báo -> tắt live -> chờ (số phút ở ô "bật lại sau", mặc định 10) -> bật lại live. Ngoại lệ: thông báo ghi hạn chế / vi phạm
  với thời hạn từ 24 giờ trở lên (7 ngày...) hoặc "vĩnh viễn / permanently" thì tắt live và KHÔNG bật lại như mục 2. Chữ "7 days" trong một
  thông báo không liên quan hạn chế (vd "bản ghi lại được lưu 7 ngày") KHÔNG bị coi là hạn chế dài.
  Cách nhận ra: theo HÌNH DẠNG chứ không theo câu chữ (nên thông báo nào, tiếng nào cũng nhận): một khung nền phẳng nằm giữa cửa sổ, có
  dòng chữ phía trên và một hàng nút phẳng bên dưới (nút hồng của TikTok, hoặc nút kiểu OK / Got it / Appeal / Close / Learn more...).
  Cách đóng thông báo (an toàn): chỉ bấm các nút kiểu OK / Got it / Understood / Close / Dismiss / Later / Đã hiểu / Đóng; thông báo chỉ có
  nút lạ (Update, Restart, Fix now...) thì nhấn ESC, KHÔNG bấm nút đó vì không biết nó làm gì. Đóng không được thì ghi nhật ký và vẫn
  tiếp tục tắt live.
  Các chốt chống tắt nhầm live:
    - Cần thấy đồng hồ live ở lần chụp đó hoặc trong 15 phút gần đây (không thì coi là live đang tắt, không làm gì).
    - Chuột bị dịch chuyển giữa 2 lần kiểm tra (người đang thao tác trên máy) thì tạm không coi hộp thoại là thông báo, 90 giây sau khi
      người ngừng thao tác mà hộp vẫn còn mới xử lý. Hộp thoại của chính TikTok Guard không bị tính.
    - Hộp thoại của chính Studio khi bạn tự thao tác (Log out, End now...) và bảng tổng kết sau khi tắt live không bị coi là thông báo.
    - Thông báo thuộc danh sách bỏ qua (mặc định: "phiên bản mới / update available") không làm gì.
    - Tối đa 3 lần / giờ; cùng một thông báo vừa xử lý xong mà còn hiện thì không lặp lại trong 30 phút.
    - Phải thấy thông báo ở 2 lần chụp cách nhau 1 giây.
  Tắt tính năng này: bỏ tick "Thông báo/hộp thoại bất kỳ ... cũng tắt live rồi bật lại" ở mục Cài đặt rồi bấm Lưu.
  Chỉnh thêm trong %APPDATA%\TikTokGuard\config.json: notice_enabled, notice_max_per_hour, notice_idle_seconds, notice_button_labels (nhãn nút
  được tính là hộp thông báo), notice_dismiss_labels (nhãn nút được phép bấm để đóng), notice_ignore_keywords (chữ trong thông báo cần bỏ qua).
  Mỗi lần xử lý có ảnh lưu ở %APPDATA%\TikTokGuard\last_notice.png và dòng "Phát hiện thông báo của TikTok che màn hình live" trong guard.log.
Giao diện đơn giản: trạng thái, Bắt đầu/Dừng, số phút bật lại live, khởi động cùng Windows, cập nhật nóng, nhật ký.

CÀI ĐẶT
  1. Giải nén TOÀN BỘ file zip.
  2. Bấm đúp install.bat (cần internet; lần đầu mất vài phút để tải thư viện). Máy chưa có Python 3.10-3.12 thì
     install.bat tự cài: thử winget trước, lỗi thì tự tải thẳng từ python.org. Nếu Windows hiện cảnh báo SmartScreen:
     chọn "More info" > "Run anyway".
     Nếu vẫn báo lỗi chứng chỉ / không cài được Python (hay gặp ở máy thuê có mạng bị chặn hoặc sai ngày giờ): kiểm tra ngày giờ
     của máy, hoặc tự cài Python 3.12 từ python.org (tick "Add python.exe to PATH") rồi chạy lại install.bat.
  3. Mở "TikTok Guard" từ Desktop hoặc Start Menu. Mở lên là tự bắt đầu theo dõi.
  Cài đè lên bản 1.x / 2.0 / 2.1.x được (cấu hình thời gian cũ được giữ, phần Telegram/spam/ảnh mẫu của bản cũ không còn dùng).
  Gỡ cài đặt: uninstall.bat.  Cấu hình và nhật ký nằm ở %APPDATA%\TikTokGuard.
  Thuê nhiều máy: cài riêng trên từng máy (từ bản 2.1.1 trở đi các lần sau cập nhật nóng, không cần cài lại).

CẬP NHẬT NÓNG (từ 2.1.1)
  Phần mềm tự tải bản mới, kiểm tra, thay file và tự khởi động lại (vài giây, live không bị ảnh hưởng).
  Cách dùng - cần 1 chỗ đặt 2 file, tải được bằng link https (GitHub, máy chủ riêng, Dropbox...):
     TikTokGuard_x.y.z.zip   (chính là file zip cài đặt của bản mới, tôi gửi cho bạn mỗi lần có bản mới)
     latest.json             (tôi gửi kèm, nội dung dạng:
        {"version": "x.y.z", "url": "TikTokGuard_x.y.z.zip", "sha256": "...", "notes": "Sửa ..."}
      "url" là link tương đối cạnh latest.json, hoặc link đầy đủ https://... nếu để ở chỗ khác)
  Trên mỗi máy: dán link tới latest.json vào ô "Link cập nhật" > Lưu. Từ đó cứ 6 giờ phần mềm tự kiểm tra một lần
  (cũng có nút "Kiểm tra cập nhật"). Có bản mới thì tự cài khi phần mềm RẢNH, tức không đang xử lý cảnh báo, không đang chờ bật
  lại live, không đang đăng xuất; đang bận thì chờ xong mới cài. Bỏ tick "tự cập nhật" nếu muốn tự bấm.
  Không có link / máy không ra internet: chép file TikTokGuard_x.y.z.zip vào máy rồi bấm "Cập nhật từ file…".
  An toàn:
    - Chỉ nhận link https. Gói được kiểm sha256 (nếu latest.json có), kiểm cú pháp, rồi CHẠY THỬ bản mới trước khi cài.
    - Trước khi thay file có sao lưu bản cũ ở %APPDATA%\TikTokGuard\update_backup.
    - Cài xong mà bản mới không khởi động được trong ~45 giây thì tự khôi phục bản cũ, ghi nhật ký, đánh dấu bản lỗi
      để không tự thử lại (cập nhật thủ công vẫn được).
    - Ai sửa được file ở link đó thì điều khiển được phần mềm trên mọi máy: chỉ đặt ở nơi chỉ mình bạn có quyền ghi
      (vd repo GitHub công khai nhưng chỉ bạn có quyền sửa), đừng chia sẻ quyền sửa.
    - Cập nhật chỉ thay các file chương trình (.py, requirements.txt, icon.ico). Nếu bản mới cần thư viện mới thì phần mềm
      tự pip install trước khi thay. Việc đổi install.bat / .bat khác thì vẫn phải cài lại bằng tay.

KIỂM TRA LẦN ĐẦU (2 phút, nên làm trước khi để chạy một mình)
  1. Mở TikTok LIVE Studio ở màn hình đang live (thấy đồng hồ đếm giờ ở góc dưới phải), để nguyên trên màn hình.
  2. Chạy kiem_tra_man_hinh.bat (trong thư mục zip). Sau 8 giây nó chụp + đọc màn hình, KHÔNG click gì.
     Kết quả cần thấy: "Cửa sổ TikTok LIVE Studio: thấy" và "Đồng hồ đếm giờ live ...: thấy tại (...)".
     Muốn thử nhận ra thông báo: mở 1 hộp thông báo/hộp thoại bất kỳ của Studio giữa màn hình rồi chạy kiem_tra_man_hinh.bat, xem dòng
     "Hộp thông báo bất kỳ che màn hình live: CÓ - nút: ..." (nút nào, sẽ tắt/bật hay tắt hẳn).
     Ảnh debug_last.png mở ra: khung đỏ = chữ đọc được, vòng xanh lá = chỗ phần mềm nghĩ là ảnh đại diện (phải nằm đúng
     ảnh đại diện của bạn ở góc trên bên phải).
  3. Muốn xem trước luồng sẽ bấm vào đâu mà không bấm thật: mở cmd, chạy
        "%LOCALAPPDATA%\TikTokGuard\venv\Scripts\python.exe" "%LOCALAPPDATA%\TikTokGuard\app\guard.py" --simulate severe --dry-run
     (--simulate short --dry-run cho luồng 10 phút, --simulate notice --dry-run cho luồng thông báo bất kỳ). Nó chỉ ghi nhật ký "sẽ bấm ... tại ..." rồi dừng.

CÁCH PHÂN BIỆT 10 PHÚT / 7 NGÀY
  Phần mềm đọc thời hạn ghi trong thông báo ("10 minutes", "10 phút", "7 days", "7 ngày"...):
    - dưới 24 giờ  -> tắt live, chờ đủ thời hạn (tối thiểu bằng số phút ở ô "bật lại sau"), bật lại.
    - từ 24 giờ trở lên (24 giờ, 3 ngày, 7 ngày, 1 tuần, 1 tháng) -> tắt live, không bật lại (đăng xuất nếu bạn tick ô đăng xuất).
    - đọc không ra thời hạn: coi là ngắn (tắt rồi bật lại), trừ khi có cụm "7 days / 7 ngày / 1 week / 1 month / permanent / vĩnh viễn".
  Thời hạn chỉ được đọc từ dòng cảnh báo trở xuống: chữ như "trong 3 ngày LIVE hôm nay" của khung Nhiệm vụ ở phía trên
  không bị nhầm là thời hạn hạn chế.
  Chống bấm nhầm: chỉ hành động khi thấy bằng chứng đây là thông báo thật (nút OK/Appeal của hộp thoại, hoặc tin nhắn có
  tiêu đề "System" trong chat) - bình luận của người xem giống y câu cảnh báo sẽ bị bỏ qua; phải thấy cảnh báo ở 2 lần chụp
  cách nhau 1 giây; 2 lần đọc ra khác nhau thì chọn việc nhẹ (tắt rồi bật lại), không dừng hẳn.
  Tin "System" thường nằm lại trong khung chat sau khi đã xử lý: phần mềm ghi nhớ giờ gửi của tin (lưu trong handled.json)
  nên không tắt/bật lại lặp đi lặp lại vì cùng một tin, kể cả khi mở lại phần mềm.

NHỮNG GÌ CHƯA ĐƯỢC KIỂM TRA THẬT (nói thẳng)
  - Tôi không có máy Windows + TikTok LIVE Studio của bạn. Phần đọc thông báo 7 ngày (tin System tiếng Việt), hộp thoại
    "Log out of ...?" (ô tick + nút Log out), tìm ảnh đại diện, tìm đồng hồ đếm giờ live và mục "End LIVE" trong menu đã được thử
    trên đúng các ảnh chụp bạn gửi, bằng OCR thật. Phần bấm chuột thật vào Studio thì chỉ thử trên màn hình giả dựng từ chính
    các ảnh đó.
  - Bảng tổng kết sau khi tắt live đã thử trên đúng ảnh bạn gửi: phần mềm nhận ra bảng (Duration / Total views / New followers /
    "How was your LIVE experience?") rồi tìm dấu X của bảng, kết quả ra khoảng (1309,129) trên ảnh 1636x940 của bạn, còn dấu X
    đóng cửa sổ Studio (1477,87) bị loại ra hẳn. Ảnh bạn khoanh vàng nằm ở dấu X đóng CỬA SỔ; tôi hiểu ý bạn là dấu X của
    bảng (vì chỉ đóng bảng thì mới thấy Go LIVE), nên chỉ bấm X của bảng. Nếu thật ra X bạn cần bấm là cái khác, báo tôi.
    Nếu không tìm thấy X hoặc bấm 4 lần mà bảng không đóng, phần mềm ghi "Không đóng được bảng tổng kết" vào nhật ký, dừng
    ở đó (không bấm bừa) và lưu ảnh debug.
  - Thông báo bất kỳ: tôi chỉ có ảnh thật của 2 hộp thoại (hộp cảnh báo 10 phút và hộp Log out) nên các hộp khác (lỗi mạng, cảnh báo vi phạm
    khác...) được thử trên hộp dựng lại theo đúng kiểu hai hộp đó (nền phẳng, nút hồng/xám) với chữ và nút khác nhau. Nếu Studio của bạn
    có hộp trông khác hẳn (không có hàng nút, nền là hình ảnh, nút nằm lệch...) thì phần mềm sẽ KHÔNG nhận ra (an toàn hơn là tắt nhầm
    live); khi đó gửi tôi ảnh hộp đó. Ngược lại, nếu thấy phần mềm tắt live vì một hộp bạn không muốn, xem dòng "Phát hiện thông báo..."
    trong guard.log và ảnh last_notice.png rồi gửi tôi, hoặc thêm chữ của hộp đó vào notice_ignore_keywords.
  - CHƯA thấy ảnh thật của 2 thứ: (a) hộp thoại xác nhận sau khi bấm End LIVE (nếu có), phần mềm tìm các nút tên "End now /
    End / Confirm / Yes / OK / Kết thúc / Xác nhận"; (b) nút Go LIVE sau khi đã đóng bảng tổng kết: phần mềm tìm nút có chữ
    "Go LIVE". Nếu Studio của bạn khác, luồng 10 phút sẽ báo lỗi trong nhật ký và dừng ở đó (không làm gì bậy); gửi tôi ảnh
    2 màn hình đó.
  - Thông báo 10 phút bằng TIẾNG VIỆT chưa thấy mẫu thật: phần mềm đoán theo kiểu "...trong 10 phút". Nếu Studio của bạn
    hiện thông báo 10 phút tiếng Việt mà phần mềm không phản ứng: mở %APPDATA%\TikTokGuard\guard.log, tìm dòng
    "Phát hiện cảnh báo" (hoặc "bỏ qua") để xem chữ đọc được, và gửi tôi ảnh thông báo đó.
  - Vị trí ảnh đại diện được tự nhận ra (hình tròn đặc, sát nút cửa sổ ở góc phải). Không nhận ra được thì dùng vị trí ước
    lượng theo bố cục, và chỉ coi là đúng khi thấy menu có chữ "Log out" hiện ra; sai thì nhấn ESC rồi thử vị trí kế tiếp.
    Không đăng xuất được thì ghi "Không đăng xuất được... hãy đăng xuất thủ công" vào nhật ký.
  - Cập nhật nóng đã thử bằng tiến trình thật trên Linux (thành công / bản lỗi tự khôi phục / gói hỏng bị chặn). Riêng phần
    đặc thù Windows - nhả khoá "chỉ 1 bản chạy" cho tiến trình mới và mở lại bằng pythonw - chưa thử được, nên lần cập nhật
    đầu tiên trên mỗi máy hãy theo dõi nhật ký xem có dòng "Đã cập nhật lên bản ..." không.

LƯU Ý KHI ĐANG CHẠY
  - Giữ cửa sổ TikTok LIVE Studio hiển thị trên màn hình (không thu nhỏ, không bị che hoàn toàn).
  - Lúc phần mềm đang click, đừng chạm chuột. Dừng khẩn cấp: đưa chuột vào góc màn hình, hoặc bấm "Dừng theo dõi".
  - Đang chờ bật lại live mà bấm "Dừng theo dõi" thì live sẽ KHÔNG được bật lại.
  - Nếu lúc có cảnh báo mà live đã tắt sẵn thì phần mềm không tự bật lại live.
  - Sau khi dừng vì hạn chế từ 24 giờ, phần mềm vẫn chạy: khi bạn tự bật live lại (hoặc đăng nhập lại nếu đã đăng xuất) là tiếp tục bảo vệ.
  - Ảnh cảnh báo gần nhất lưu ở %APPDATA%\TikTokGuard\last_warning.png, nhật ký ở guard.log.

SO VỚI BẢN 2.1.x
  2.3.0: phản ứng NGAY (nhìn nhanh 2 giây, đọc chữ 10 giây, xác nhận 1 giây); hạn chế từ 24 giờ (hoặc vĩnh viễn) = tắt live, KHÔNG bật lại,
         KHÔNG còn tự đăng xuất (bật lại bằng ô trong Cài đặt); đọc thêm thời hạn "tháng".
  2.2.0: thêm xử lý BẤT KỲ thông báo/hộp thoại nào của TikTok che màn hình live (xem mục riêng ở trên).
  2.1.2: sau khi tắt live tự đóng bảng tổng kết (bấm X của chính bảng) để thấy nút Go LIVE.
  2.1.1: cập nhật nóng, sửa luồng tắt live qua đồng hồ đếm giờ, sửa cài đặt trên máy thuê.

SO VỚI BẢN 2.0
  Bản 2.1 đã BỎ HẾT những gì ngoài 2 việc trên: Telegram, phát hiện spam donate, cổng API, thông báo sang LiveCharacter,
  đếm ngược/popup trước khi tắt live, tab Cài đặt chi tiết, tab Ảnh mẫu, các nút chạy thử trên giao diện.
  LiveCharacter không bị đổi gì và vẫn có Guard riêng bên trong: đừng để 2 Guard cùng chạy trên một máy vì sẽ cùng click vào
  Live Studio. Mở TikTok Guard 2.1 trước thì LiveCharacter tự không bật Guard của nó; nếu LiveCharacter đã bật Guard rồi thì
  hãy dừng theo dõi bên LiveCharacter trước khi mở bản này.

TÙY CHỌN: build_exe.bat tạo TikTokGuard.exe chạy độc lập (chạy install.bat trước). Bản exe không dùng được cập nhật nóng.
