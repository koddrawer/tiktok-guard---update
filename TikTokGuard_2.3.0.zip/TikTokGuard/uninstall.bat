@echo off
setlocal EnableExtensions
title Go cai dat TikTok Guard
set "APP=%LOCALAPPDATA%\TikTokGuard"

echo Dang go cai dat TikTok Guard...
taskkill /F /IM pythonw.exe /FI "WINDOWTITLE eq TikTok Guard*" >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v TikTokGuard /f >nul 2>&1
powershell -NoProfile -Command "foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){ Remove-Item (Join-Path $d 'TikTok Guard.lnk') -ErrorAction SilentlyContinue }"
if exist "%APP%" rmdir /S /Q "%APP%"

echo.
echo Da go chuong trinh. Cau hinh va nhat ky van con trong:
echo   %APPDATA%\TikTokGuard
echo.
choice /C YN /M "Xoa luon du lieu nay"
if errorlevel 2 goto :done
if exist "%APPDATA%\TikTokGuard" rmdir /S /Q "%APPDATA%\TikTokGuard"
echo Da xoa du lieu.

:done
pause
exit /b 0
