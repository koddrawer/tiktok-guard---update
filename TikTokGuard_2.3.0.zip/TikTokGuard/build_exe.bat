@echo off
rem TUY CHON: dong goi thanh TikTokGuard.exe chay doc lap (khong can Python). Chay install.bat truoc.
setlocal EnableExtensions
set "PYEXE=%LOCALAPPDATA%\TikTokGuard\venv\Scripts\python.exe"
if not exist "%PYEXE%" (
  echo Hay chay install.bat truoc.
  pause
  exit /b 1
)
cd /d "%~dp0app"
"%PYEXE%" -m pip install pyinstaller --disable-pip-version-check
"%PYEXE%" -m PyInstaller --noconfirm --clean --windowed --name TikTokGuard --icon icon.ico --add-data "icon.ico;." --collect-all rapidocr_onnxruntime --collect-all onnxruntime app.py
echo.
echo Xong. File chay: %~dp0app\dist\TikTokGuard\TikTokGuard.exe  (copy ca thu muc TikTokGuard di noi khac neu muon)
pause
