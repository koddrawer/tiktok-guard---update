param(
    [Parameter(Mandatory = $true)][string]$Target,
    [Parameter(Mandatory = $true)][string]$Script,
    [Parameter(Mandatory = $true)][string]$WorkDir,
    [string]$Icon = ""
)
$ErrorActionPreference = "Stop"
$shell = New-Object -ComObject WScript.Shell
$dirs = @([Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("Programs"))
foreach ($d in $dirs) {
    $lnk = Join-Path $d "TikTok Guard.lnk"
    $s = $shell.CreateShortcut($lnk)
    $s.TargetPath = $Target
    $s.Arguments = '"' + $Script + '"'
    $s.WorkingDirectory = $WorkDir
    if ($Icon -and (Test-Path $Icon)) { $s.IconLocation = $Icon }
    $s.Description = "TikTok Guard"
    $s.Save()
    Write-Host "Da tao shortcut: $lnk"
}
